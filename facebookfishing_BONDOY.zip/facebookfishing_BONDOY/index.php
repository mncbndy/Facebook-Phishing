<!DOCTYPE html>
<html lang="en" id="facebook" class="no_js">

<head>
    <meta charset="utf-8" />
    <meta name="referrer" content="origin-when-crossorigin" id="meta_referrer" />
    <script nonce="sw0CYq7E">
        function envFlush(a) {
            function b(b) {
                for (var c in a) b[c] = a[c]
            }
            window.requireLazy ? window.requireLazy(["Env"], b) : (window.Env = window.Env || {}, b(window.Env))
        }
        envFlush({
            "useTrustedTypes": false,
            "isTrustedTypesReportOnly": false,
            "ajaxpipe_token": "AXhuL90M1hHsdIqY3Do",
            "stack_trace_limit": 30,
            "timesliceBufferSize": 5000,
            "show_invariant_decoder": false,
            "compat_iframe_token": "AQ4i_xoT43tj6vXrKkY",
            "isCQuick": false
        });
    </script>
    <script nonce="sw0CYq7E">
        (function(a) {
            function b(b) {
                if (!window.openDatabase) return;
                b.I_AM_INCOGNITO_AND_I_REALLY_NEED_WEBSQL = function(a, b, c, d) {
                    return window.openDatabase(a, b, c, d)
                };
                window.openDatabase = function() {
                    throw new Error()
                }
            }
            b(a)
        })(this);
    </script>
    <style nonce="sw0CYq7E"></style>
    <script nonce="sw0CYq7E">
        __DEV__ = 0;
    </script><noscript>
        <meta http-equiv="refresh" content="0; URL=/?_fb_noscript=1" />
    </noscript>
    <link rel="manifest" id="MANIFEST_LINK" href="/data/manifest/" crossorigin="use-credentials" />
    <title id="pageTitle">Facebook – log in or sign up</title>
    <meta property="og:site_name" content="Facebook" />
    <meta property="og:url" content="https://www.facebook.com/" />
    <meta property="og:image" content="https://www.facebook.com/images/fb_icon_325x325.png" />
    <meta property="og:locale" content="en_GB" />
    <link rel="alternate" media="only screen and (max-width: 640px)" href="https://m.facebook.com/" />
    <link rel="alternate" media="handheld" href="https://m.facebook.com/" />
    <meta name="description" content="Log in to Facebook to start sharing and connecting with your friends, family and people you know." />
    <script type="application/ld+json" nonce="sw0CYq7E">
        {
            "\u0040context": "http:\/\/schema.org",
            "\u0040type": "WebSite",
            "name": "Facebook",
            "url": "https:\/\/en-gb.facebook.com\/"
        }
    </script>
    <link rel="canonical" href="https://www.facebook.com/" />
    <link rel="icon" href="https://static.xx.fbcdn.net/rsrc.php/yb/r/hLRJ1GG_y0J.ico" />
    <link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/yK/l/0,cross/muxPbqTSEFj.css?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="CZi7qX1" crossorigin="anonymous" />
    <link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/ym/l/0,cross/_8GO0yQCxDC.css?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="35HYsYr" crossorigin="anonymous" />
    <link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/yT/l/0,cross/MshTbk_kQ__.css?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="KJRUhY0" crossorigin="anonymous" />
    <link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/y4/l/0,cross/mqcI9d4wGSv.css?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="p1Lj6Su" crossorigin="anonymous" />
    <link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/y7/l/0,cross/55Y7V8hpXwd.css?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="oMslBxQ" crossorigin="anonymous" />
    <link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/y7/l/0,cross/xDrFK0a8hmo.css?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="AC8VrTj" crossorigin="anonymous" />
    <script src="https://static.xx.fbcdn.net/rsrc.php/v3/yJ/r/MMvN_VzNUPQ.js?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="rFzyveS" crossorigin="anonymous" nonce="sw0CYq7E"></script>
    <script nonce="sw0CYq7E">
        requireLazy(["HasteSupportData"], function(m) {
            m.handle({
                "clpData": {
                    "1744178": {
                        "r": 1,
                        "s": 1
                    },
                    "1814852": {
                        "r": 1
                    },
                    "1838142": {
                        "r": 1,
                        "s": 1
                    },
                    "4883": {
                        "r": 1,
                        "s": 1
                    },
                    "1837559": {
                        "r": 1
                    },
                    "1848815": {
                        "r": 10000,
                        "s": 1
                    }
                },
                "gkxData": {
                    "7742": {
                        "result": false,
                        "hash": null
                    },
                    "20836": {
                        "result": false,
                        "hash": null
                    },
                    "20935": {
                        "result": false,
                        "hash": null
                    },
                    "20936": {
                        "result": false,
                        "hash": null
                    },
                    "20939": {
                        "result": true,
                        "hash": null
                    },
                    "20940": {
                        "result": false,
                        "hash": null
                    },
                    "20979": {
                        "result": false,
                        "hash": null
                    },
                    "20980": {
                        "result": false,
                        "hash": null
                    },
                    "20981": {
                        "result": false,
                        "hash": null
                    },
                    "20982": {
                        "result": false,
                        "hash": null
                    },
                    "20983": {
                        "result": false,
                        "hash": null
                    },
                    "20984": {
                        "result": true,
                        "hash": null
                    },
                    "20985": {
                        "result": false,
                        "hash": null
                    },
                    "20986": {
                        "result": false,
                        "hash": null
                    },
                    "20987": {
                        "result": false,
                        "hash": null
                    },
                    "20988": {
                        "result": true,
                        "hash": null
                    },
                    "21043": {
                        "result": false,
                        "hash": null
                    },
                    "21050": {
                        "result": false,
                        "hash": null
                    },
                    "21051": {
                        "result": false,
                        "hash": null
                    },
                    "21052": {
                        "result": false,
                        "hash": null
                    },
                    "21053": {
                        "result": false,
                        "hash": null
                    },
                    "21054": {
                        "result": false,
                        "hash": null
                    },
                    "21055": {
                        "result": false,
                        "hash": null
                    },
                    "21056": {
                        "result": false,
                        "hash": null
                    },
                    "21057": {
                        "result": false,
                        "hash": null
                    },
                    "21058": {
                        "result": false,
                        "hash": null
                    },
                    "21059": {
                        "result": false,
                        "hash": null
                    },
                    "21074": {
                        "result": false,
                        "hash": null
                    },
                    "21075": {
                        "result": false,
                        "hash": null
                    },
                    "21076": {
                        "result": true,
                        "hash": null
                    },
                    "21106": {
                        "result": false,
                        "hash": null
                    },
                    "21107": {
                        "result": false,
                        "hash": null
                    },
                    "21117": {
                        "result": false,
                        "hash": null
                    },
                    "22681": {
                        "result": false,
                        "hash": null
                    },
                    "22773": {
                        "result": false,
                        "hash": null
                    },
                    "22785": {
                        "result": false,
                        "hash": null
                    },
                    "22792": {
                        "result": false,
                        "hash": null
                    },
                    "22803": {
                        "result": false,
                        "hash": null
                    },
                    "22826": {
                        "result": false,
                        "hash": null
                    },
                    "22827": {
                        "result": true,
                        "hash": null
                    },
                    "22875": {
                        "result": false,
                        "hash": null
                    },
                    "22876": {
                        "result": false,
                        "hash": null
                    },
                    "22877": {
                        "result": true,
                        "hash": null
                    },
                    "22879": {
                        "result": false,
                        "hash": null
                    },
                    "22979": {
                        "result": false,
                        "hash": null
                    },
                    "26334": {
                        "result": false,
                        "hash": null
                    },
                    "26340": {
                        "result": false,
                        "hash": null
                    },
                    "26341": {
                        "result": false,
                        "hash": null
                    },
                    "26342": {
                        "result": false,
                        "hash": null
                    },
                    "26398": {
                        "result": false,
                        "hash": null
                    },
                    "20948": {
                        "result": true,
                        "hash": null
                    },
                    "25572": {
                        "result": false,
                        "hash": null
                    },
                    "25571": {
                        "result": false,
                        "hash": null
                    }
                },
                "ixData": {
                    "701592": {
                        "sprited": 1,
                        "spriteCssClass": "sx_02fbad",
                        "spriteMapCssClass": "sp_YR_DzQmu5lo_1_5x"
                    },
                    "702721": {
                        "sprited": 1,
                        "spriteCssClass": "sx_f0f728",
                        "spriteMapCssClass": "sp_YR_DzQmu5lo_1_5x"
                    },
                    "897949": {
                        "sprited": 1,
                        "spriteCssClass": "sx_50d846",
                        "spriteMapCssClass": "sp_YR_DzQmu5lo_1_5x"
                    },
                    "1739808": {
                        "sprited": 1,
                        "spriteCssClass": "sx_463474",
                        "spriteMapCssClass": "sp_YR_DzQmu5lo_1_5x"
                    }
                },
                "qexData": {
                    "526": {
                        "r": null
                    },
                    "538": {
                        "r": null
                    },
                    "543": {
                        "r": null
                    },
                    "723": {
                        "r": null
                    }
                },
                "justknobxData": {
                    "144": {
                        "r": true
                    },
                    "450": {
                        "r": true
                    },
                    "1203": {
                        "r": true
                    }
                }
            })
        });
        requireLazy(["TimeSliceImpl", "ServerJS"], function(TimeSlice, ServerJS) {
            (new ServerJS()).handle({
                "define": [
                    ["cr:310", ["RunWWW"], {
                        "__rc": ["RunWWW", null]
                    }, -1],
                    ["cr:1126", ["TimeSliceImpl"], {
                        "__rc": ["TimeSliceImpl", null]
                    }, -1],
                    ["cr:6640", ["PromiseImpl"], {
                        "__rc": ["PromiseImpl", null]
                    }, -1],
                    ["cr:7386", ["clearTimeoutWWW"], {
                        "__rc": ["clearTimeoutWWW", null]
                    }, -1],
                    ["cr:7390", ["setTimeoutWWW"], {
                        "__rc": ["setTimeoutWWW", null]
                    }, -1],
                    ["cr:8958", ["FBJSON"], {
                        "__rc": ["FBJSON", null]
                    }, -1],
                    ["cr:1078", [], {
                        "__rc": [null, null]
                    }, -1],
                    ["cr:1080", ["unexpectedUseInComet"], {
                        "__rc": ["unexpectedUseInComet", null]
                    }, -1],
                    ["cr:6108", ["CSS"], {
                        "__rc": ["CSS", null]
                    }, -1],
                    ["cr:7385", ["clearIntervalWWW"], {
                        "__rc": ["clearIntervalWWW", null]
                    }, -1],
                    ["cr:7389", ["setIntervalAcrossTransitionsWWW"], {
                        "__rc": ["setIntervalAcrossTransitionsWWW", null]
                    }, -1],
                    ["cr:7391", ["setTimeoutAcrossTransitionsWWW"], {
                        "__rc": ["setTimeoutAcrossTransitionsWWW", null]
                    }, -1],
                    ["cr:7936", ["BlueCompatRouter"], {
                        "__rc": ["BlueCompatRouter", null]
                    }, -1],
                    ["cr:8959", ["DTSG"], {
                        "__rc": ["DTSG", null]
                    }, -1],
                    ["cr:8960", ["DTSG_ASYNC"], {
                        "__rc": ["DTSG_ASYNC", null]
                    }, -1],
                    ["cr:696703", [], {
                        "__rc": [null, null]
                    }, -1],
                    ["cr:708886", ["EventProfilerImpl"], {
                        "__rc": ["EventProfilerImpl", null]
                    }, -1],
                    ["cr:135", ["RunBlue"], {
                        "__rc": ["RunBlue", null]
                    }, -1],
                    ["cr:6669", ["DataStore"], {
                        "__rc": ["DataStore", null]
                    }, -1],
                    ["ServerNonce", [], {
                        "ServerNonce": "Hs5I0Jtx9yjxuTyUdUyn11"
                    }, 141],
                    ["KSConfig", [], {
                        "killed": {
                            "__set": ["POCKET_MONSTERS_CREATE", "POCKET_MONSTERS_DELETE", "WORKPLACE_PLATFORM_SECURE_APPS_MAILBOXES", "POCKET_MONSTERS_UPDATE_NAME", "TPA_SRT_TRANSLATION", "WORKROOMS_REQUEST_TAGGING_TAG_NO_INIT_BY_VC_GALAXY"]
                        },
                        "ko": {
                            "__set": ["acrJTh9WGdp", "1oOE64fL4wO", "5XCz1h9Iaw3", "7r6mSP7ofr2", "3sKizTQ6byg", "6XsXQ2qHw8y"]
                        }
                    }, 2580],
                    ["InitialCookieConsent", [], {
                        "deferCookies": false,
                        "initialConsent": [1, 2],
                        "noCookies": false,
                        "shouldShowCookieBanner": false,
                        "shouldWaitForDeferredDatrCookie": false
                    }, 4328],
                    ["CookieConsentIFrameConfig", [], {
                        "consent_param": "FQAREhISAA==.ARZMlcaZ7KSgjyaEYeBThK9RkAebPm4QMbHzl3LMHra03zH_",
                        "allowlisted_iframes": [],
                        "is_checkpointed": false
                    }, 5540],
                    ["ServerTimeData", [], {
                        "serverTime": 1709710377587,
                        "timeOfRequestStart": 1709710377564.7,
                        "timeOfResponseStart": 1709710377564.7
                    }, 5943],
                    ["URLFragmentPreludeConfig", [], {
                        "hashtagRedirect": true,
                        "fragBlacklist": ["nonce", "access_token", "oauth_token", "xs", "checkpoint_data", "code"]
                    }, 137],
                    ["CometPersistQueryParams", [], {
                        "relative": {},
                        "domain": {}
                    }, 6231],
                    ["CookieDomain", [], {
                        "domain": "facebook.com"
                    }, 6421],
                    ["GetAsyncParamsExtraData", [], {
                        "extra_data": {}
                    }, 7511],
                    ["BootloaderConfig", [], {
                        "deferBootloads": false,
                        "jsRetries": [200, 500],
                        "jsRetryAbortNum": 2,
                        "jsRetryAbortTime": 5,
                        "silentDups": false,
                        "timeout": 60000,
                        "tieredLoadingFromTier": 100,
                        "hypStep4": false,
                        "phdOn": false,
                        "btCutoffIndex": 2300,
                        "fastPathForAlreadyRequired": true,
                        "earlyRequireLazy": false,
                        "enableTimeoutLoggingForNonComet": false,
                        "deferLongTailManifest": true,
                        "lazySoT": false,
                        "translationRetries": [200, 500],
                        "translationRetryAbortNum": 3,
                        "translationRetryAbortTime": 50
                    }, 329],
                    ["CSSLoaderConfig", [], {
                        "timeout": 5000,
                        "modulePrefix": "BLCSS:",
                        "forcePollForBootloader": true,
                        "loadEventSupported": true
                    }, 619],
                    ["CookieCoreConfig", [], {
                        "c_user": {
                            "t": 31536000,
                            "s": "None"
                        },
                        "cppo": {
                            "t": 86400,
                            "s": "None"
                        },
                        "dpr": {
                            "t": 604800,
                            "s": "None"
                        },
                        "fbl_ci": {
                            "t": 31536000,
                            "s": "None"
                        },
                        "fbl_cs": {
                            "t": 31536000,
                            "s": "None"
                        },
                        "fbl_st": {
                            "t": 31536000,
                            "s": "Strict"
                        },
                        "i_user": {
                            "t": 31536000,
                            "s": "None"
                        },
                        "locale": {
                            "t": 604800,
                            "s": "None"
                        },
                        "m_ls": {
                            "t": 34560000,
                            "s": "None"
                        },
                        "m_pixel_ratio": {
                            "t": 604800,
                            "s": "None"
                        },
                        "noscript": {
                            "s": "None"
                        },
                        "presence": {
                            "t": 2592000,
                            "s": "None"
                        },
                        "sfau": {
                            "s": "None"
                        },
                        "usida": {
                            "s": "None"
                        },
                        "vpd": {
                            "t": 5184000,
                            "s": "Lax"
                        },
                        "wd": {
                            "t": 604800,
                            "s": "Lax"
                        },
                        "wl_cbv": {
                            "t": 7776000,
                            "s": "None"
                        },
                        "x-referer": {
                            "s": "None"
                        },
                        "x-src": {
                            "t": 1,
                            "s": "None"
                        }
                    }, 2104],
                    ["CurrentUserInitialData", [], {
                        "ACCOUNT_ID": "0",
                        "USER_ID": "0",
                        "NAME": "",
                        "SHORT_NAME": null,
                        "IS_BUSINESS_PERSON_ACCOUNT": false,
                        "HAS_SECONDARY_BUSINESS_PERSON": false,
                        "IS_FACEBOOK_WORK_ACCOUNT": false,
                        "IS_MESSENGER_ONLY_USER": false,
                        "IS_DEACTIVATED_ALLOWED_ON_MESSENGER": false,
                        "IS_MESSENGER_CALL_GUEST_USER": false,
                        "IS_WORK_MESSENGER_CALL_GUEST_USER": false,
                        "IS_WORKROOMS_USER": false,
                        "APP_ID": "256281040558",
                        "IS_BUSINESS_DOMAIN": false
                    }, 270],
                    ["LSD", [], {
                        "token": "AVog4YTn4SI"
                    }, 323],
                    ["SiteData", [], {
                        "server_revision": 1011862899,
                        "client_revision": 1011862899,
                        "push_phase": "C3",
                        "pkg_cohort": "BP:DEFAULT",
                        "haste_session": "19788.BP:DEFAULT.2.0..0.0",
                        "pr": 1.5,
                        "manifest_base_uri": "https:\/\/static.xx.fbcdn.net",
                        "manifest_origin": null,
                        "manifest_version_prefix": null,
                        "be_one_ahead": false,
                        "is_rtl": false,
                        "is_experimental_tier": false,
                        "is_jit_warmed_up": true,
                        "hsi": "7343150156838988024",
                        "semr_host_bucket": "5",
                        "bl_hash_version": 2,
                        "comet_env": 0,
                        "wbloks_env": false,
                        "ef_page": null,
                        "compose_bootloads": false,
                        "spin": 4,
                        "__spin_r": 1011862899,
                        "__spin_b": "trunk",
                        "__spin_t": 1709710377,
                        "vip": "157.240.199.35"
                    }, 317],
                    ["SprinkleConfig", [], {
                        "param_name": "jazoest",
                        "version": 2,
                        "should_randomize": false
                    }, 2111],
                    ["UserAgentData", [], {
                        "browserArchitecture": "64",
                        "browserFullVersion": "122.0.0.0",
                        "browserMinorVersion": 0,
                        "browserName": "Chrome",
                        "browserVersion": 122,
                        "deviceName": "Unknown",
                        "engineName": "Blink",
                        "engineVersion": "122.0.0.0",
                        "platformArchitecture": "64",
                        "platformName": "Windows",
                        "platformVersion": "10",
                        "platformFullVersion": "10"
                    }, 527],
                    ["PromiseUsePolyfillSetImmediateGK", [], {
                        "www_always_use_polyfill_setimmediate": false
                    }, 2190],
                    ["JSErrorLoggingConfig", [], {
                        "appId": 256281040558,
                        "extra": [],
                        "reportInterval": 50,
                        "sampleWeight": null,
                        "sampleWeightKey": "__jssesw",
                        "projectBlocklist": []
                    }, 2776],
                    ["DataStoreConfig", [], {
                        "expandoKey": "__FB_STORE",
                        "useExpando": true
                    }, 2915],
                    ["CookieCoreLoggingConfig", [], {
                        "maximumIgnorableStallMs": 16.67,
                        "sampleRate": 9.7e-5,
                        "sampleRateClassic": 1.0e-10,
                        "sampleRateFastStale": 1.0e-8
                    }, 3401],
                    ["ImmediateImplementationExperiments", [], {
                        "prefer_message_channel": true
                    }, 3419],
                    ["UriNeedRawQuerySVConfig", [], {
                        "uris": ["dms.netmng.com", "doubleclick.net", "r.msn.com", "watchit.sky.com", "graphite.instagram.com", "www.kfc.co.th", "learn.pantheon.io", "www.landmarkshops.in", "www.ncl.com", "s0.wp.com", "www.tatacliq.com", "bs.serving-sys.com", "kohls.com", "lazada.co.th", "xg4ken.com", "technopark.ru", "officedepot.com.mx", "bestbuy.com.mx", "booking.com", "nibio.no", "myworkdayjobs.com", "united-united.com"]
                    }, 3871],
                    ["WebConnectionClassServerGuess", [], {
                        "connectionClass": "EXCELLENT"
                    }, 4705],
                    ["BootloaderEndpointConfig", [], {
                        "debugNoBatching": false,
                        "maxBatchSize": -1,
                        "endpointURI": "https:\/\/www.facebook.com\/ajax\/bootloader-endpoint\/"
                    }, 5094],
                    ["BigPipeExperiments", [], {
                        "link_images_to_pagelets": false,
                        "enable_bigpipe_plugins": false
                    }, 907],
                    ["cr:7730", ["getFbtResult"], {
                        "__rc": ["getFbtResult", null]
                    }, -1],
                    ["cr:8906", ["goURIWWW"], {
                        "__rc": ["goURIWWW", null]
                    }, -1],
                    ["cr:925100", ["RunBlue"], {
                        "__rc": ["RunBlue", null]
                    }, -1],
                    ["cr:806696", ["clearTimeoutBlue"], {
                        "__rc": ["clearTimeoutBlue", null]
                    }, -1],
                    ["cr:807042", ["setTimeoutBlue"], {
                        "__rc": ["setTimeoutBlue", null]
                    }, -1],
                    ["cr:1003267", ["clearIntervalBlue"], {
                        "__rc": ["clearIntervalBlue", null]
                    }, -1],
                    ["cr:896462", ["setIntervalAcrossTransitionsBlue"], {
                        "__rc": ["setIntervalAcrossTransitionsBlue", null]
                    }, -1],
                    ["cr:986633", ["setTimeoutAcrossTransitionsBlue"], {
                        "__rc": ["setTimeoutAcrossTransitionsBlue", null]
                    }, -1],
                    ["cr:6799", ["EventProfilerAdsSessionProvider"], {
                        "__rc": ["EventProfilerAdsSessionProvider", null]
                    }, -1],
                    ["IntlVariationHoldout", [], {
                        "disable_variation": false
                    }, 6533],
                    ["IntlNumberTypeProps", ["IntlCLDRNumberType05"], {
                        "module": {
                            "__m": "IntlCLDRNumberType05"
                        }
                    }, 7027],
                    ["AsyncRequestConfig", [], {
                        "retryOnNetworkError": "1",
                        "useFetchStreamAjaxPipeTransport": false
                    }, 328],
                    ["DTSGInitialData", [], {}, 258],
                    ["IntlPhonologicalRules", [], {
                        "meta": {
                            "\/_B\/": "([.,!?\\s]|^)",
                            "\/_E\/": "([.,!?\\s]|$)"
                        },
                        "patterns": {
                            "\/\u0001(.*)('|&#039;)s\u0001(?:'|&#039;)s(.*)\/": "\u0001$1$2s\u0001$3",
                            "\/_\u0001([^\u0001]*)\u0001\/": "javascript"
                        }
                    }, 1496],
                    ["IntlViewerContext", [], {
                        "GENDER": 3,
                        "regionalLocale": null
                    }, 772],
                    ["NumberFormatConfig", [], {
                        "decimalSeparator": ".",
                        "numberDelimiter": ",",
                        "minDigitsForThousandsSeparator": 4,
                        "standardDecimalPatternInfo": {
                            "primaryGroupSize": 3,
                            "secondaryGroupSize": 3
                        },
                        "numberingSystemData": null
                    }, 54],
                    ["SessionNameConfig", [], {
                        "seed": "1CpI"
                    }, 757],
                    ["ZeroCategoryHeader", [], {}, 1127],
                    ["ZeroRewriteRules", [], {
                        "rewrite_rules": {},
                        "whitelist": {
                            "\/hr\/r": 1,
                            "\/hr\/p": 1,
                            "\/zero\/unsupported_browser\/": 1,
                            "\/zero\/policy\/optin": 1,
                            "\/zero\/optin\/write\/": 1,
                            "\/zero\/optin\/legal\/": 1,
                            "\/zero\/optin\/free\/": 1,
                            "\/about\/privacy\/": 1,
                            "\/about\/privacy\/update\/": 1,
                            "\/privacy\/explanation\/": 1,
                            "\/zero\/toggle\/welcome\/": 1,
                            "\/zero\/toggle\/nux\/": 1,
                            "\/zero\/toggle\/settings\/": 1,
                            "\/fup\/interstitial\/": 1,
                            "\/work\/landing": 1,
                            "\/work\/login\/": 1,
                            "\/work\/email\/": 1,
                            "\/ai.php": 1,
                            "\/js_dialog_resources\/dialog_descriptions_android.json": 0,
                            "\/connect\/jsdialog\/MPlatformAppInvitesJSDialog\/": 0,
                            "\/connect\/jsdialog\/MPlatformOAuthShimJSDialog\/": 0,
                            "\/connect\/jsdialog\/MPlatformLikeJSDialog\/": 0,
                            "\/qp\/interstitial\/": 1,
                            "\/qp\/action\/redirect\/": 1,
                            "\/qp\/action\/close\/": 1,
                            "\/zero\/support\/ineligible\/": 1,
                            "\/zero_balance_redirect\/": 1,
                            "\/zero_balance_redirect": 1,
                            "\/zero_balance_redirect\/l\/": 1,
                            "\/l.php": 1,
                            "\/lsr.php": 1,
                            "\/ajax\/dtsg\/": 1,
                            "\/checkpoint\/block\/": 1,
                            "\/exitdsite": 1,
                            "\/zero\/balance\/pixel\/": 1,
                            "\/zero\/balance\/": 1,
                            "\/zero\/balance\/carrier_landing\/": 1,
                            "\/zero\/flex\/logging\/": 1,
                            "\/tr": 1,
                            "\/tr\/": 1,
                            "\/sem_campaigns\/sem_pixel_test\/": 1,
                            "\/bookmarks\/flyout\/body\/": 1,
                            "\/zero\/subno\/": 1,
                            "\/confirmemail.php": 1,
                            "\/policies\/": 1,
                            "\/mobile\/internetdotorg\/classifier\/": 1,
                            "\/zero\/dogfooding": 1,
                            "\/xti.php": 1,
                            "\/zero\/fblite\/config\/": 1,
                            "\/hr\/zsh\/wc\/": 1,
                            "\/ajax\/bootloader-endpoint\/": 1,
                            "\/mobile\/zero\/carrier_page\/": 1,
                            "\/mobile\/zero\/carrier_page\/education_page\/": 1,
                            "\/mobile\/zero\/carrier_page\/feature_switch\/": 1,
                            "\/mobile\/zero\/carrier_page\/settings_page\/": 1,
                            "\/aloha_check_build": 1,
                            "\/upsell\/zbd\/softnudge\/": 1,
                            "\/mobile\/zero\/af_transition\/": 1,
                            "\/mobile\/zero\/af_transition\/action\/": 1,
                            "\/mobile\/zero\/freemium\/": 1,
                            "\/mobile\/zero\/freemium\/redirect\/": 1,
                            "\/mobile\/zero\/freemium\/zero_fup\/": 1,
                            "\/privacy\/policy\/": 1,
                            "\/privacy\/center\/": 1,
                            "\/data\/manifest\/": 1,
                            "\/4oh4.php": 1,
                            "\/autologin.php": 1,
                            "\/birthday_help.php": 1,
                            "\/checkpoint\/": 1,
                            "\/contact-importer\/": 1,
                            "\/cr.php": 1,
                            "\/legal\/terms\/": 1,
                            "\/login.php": 1,
                            "\/login\/": 1,
                            "\/mobile\/account\/": 1,
                            "\/n\/": 1,
                            "\/remote_test_device\/": 1,
                            "\/upsell\/buy\/": 1,
                            "\/upsell\/buyconfirm\/": 1,
                            "\/upsell\/buyresult\/": 1,
                            "\/upsell\/promos\/": 1,
                            "\/upsell\/continue\/": 1,
                            "\/upsell\/h\/promos\/": 1,
                            "\/upsell\/loan\/learnmore\/": 1,
                            "\/upsell\/purchase\/": 1,
                            "\/upsell\/promos\/upgrade\/": 1,
                            "\/upsell\/buy_redirect\/": 1,
                            "\/upsell\/loan\/buyconfirm\/": 1,
                            "\/upsell\/loan\/buy\/": 1,
                            "\/upsell\/sms\/": 1,
                            "\/wap\/a\/channel\/reconnect.php": 1,
                            "\/wap\/a\/nux\/wizard\/nav.php": 1,
                            "\/wap\/appreg.php": 1,
                            "\/wap\/birthday_help.php": 1,
                            "\/wap\/c.php": 1,
                            "\/wap\/confirmemail.php": 1,
                            "\/wap\/cr.php": 1,
                            "\/wap\/login.php": 1,
                            "\/wap\/r.php": 1,
                            "\/zero\/datapolicy": 1,
                            "\/a\/timezone.php": 1,
                            "\/a\/bz": 1,
                            "\/bz\/reliability": 1,
                            "\/r.php": 1,
                            "\/mr\/": 1,
                            "\/reg\/": 1,
                            "\/registration\/log\/": 1,
                            "\/terms\/": 1,
                            "\/f123\/": 1,
                            "\/expert\/": 1,
                            "\/experts\/": 1,
                            "\/terms\/index.php": 1,
                            "\/terms.php": 1,
                            "\/srr\/": 1,
                            "\/msite\/redirect\/": 1,
                            "\/fbs\/pixel\/": 1,
                            "\/contactpoint\/preconfirmation\/": 1,
                            "\/contactpoint\/cliff\/": 1,
                            "\/contactpoint\/confirm\/submit\/": 1,
                            "\/contactpoint\/confirmed\/": 1,
                            "\/contactpoint\/login\/": 1,
                            "\/preconfirmation\/contactpoint_change\/": 1,
                            "\/help\/contact\/": 1,
                            "\/survey\/": 1,
                            "\/upsell\/loyaltytopup\/accept\/": 1,
                            "\/settings\/": 1,
                            "\/lite\/": 1,
                            "\/zero_status_update\/": 1,
                            "\/operator_store\/": 1,
                            "\/upsell\/": 1,
                            "\/wifiauth\/login\/": 1
                        }
                    }, 1478],
                    ["DTSGInitData", [], {
                        "token": "",
                        "async_get_token": ""
                    }, 3515],
                    ["WebDriverConfig", [], {
                        "isTestRunning": false,
                        "isJestE2ETestRun": false,
                        "isXRequestConfigEnabled": false,
                        "auxiliaryServiceInfo": {},
                        "testPath": null,
                        "originHost": null
                    }, 5332],
                    ["CurrentEnvironment", [], {
                        "facebookdotcom": true,
                        "messengerdotcom": false,
                        "workplacedotcom": false,
                        "instagramdotcom": false,
                        "workdotmetadotcom": false,
                        "horizondotmetadotcom": false
                    }, 827],
                    ["CometAltpayJsSdkIframeAllowedDomains", [], {
                        "allowed_domains": ["https:\/\/live.adyen.com", "https:\/\/integration-facebook.payu.in", "https:\/\/facebook.payulatam.com", "https:\/\/secure.payu.com", "https:\/\/facebook.dlocal.com", "https:\/\/buy2.boku.com"]
                    }, 4920],
                    ["EventConfig", [], {
                        "sampling": {
                            "bandwidth": 0,
                            "play": 0,
                            "playing": 0,
                            "progress": 0,
                            "pause": 0,
                            "ended": 0,
                            "seeked": 0,
                            "seeking": 0,
                            "waiting": 0,
                            "loadedmetadata": 0,
                            "canplay": 0,
                            "selectionchange": 0,
                            "change": 0,
                            "timeupdate": 0,
                            "adaptation": 0,
                            "focus": 0,
                            "blur": 0,
                            "load": 0,
                            "error": 0,
                            "message": 0,
                            "abort": 0,
                            "storage": 0,
                            "scroll": 200000,
                            "mousemove": 20000,
                            "mouseover": 10000,
                            "mouseout": 10000,
                            "mousewheel": 1,
                            "MSPointerMove": 10000,
                            "keydown": 0.1,
                            "click": 0.02,
                            "mouseup": 0.02,
                            "__100ms": 0.001,
                            "__default": 5000,
                            "__min": 100,
                            "__interactionDefault": 200,
                            "__eventDefault": 100000
                        },
                        "page_sampling_boost": 1,
                        "interaction_regexes": {},
                        "interaction_boost": {},
                        "event_types": {},
                        "manual_instrumentation": false,
                        "profile_eager_execution": false,
                        "disable_heuristic": true,
                        "disable_event_profiler": false
                    }, 1726],
                    ["cr:1290", [], {
                        "__rc": [null, null]
                    }, -1],
                    ["cr:1094907", [], {
                        "__rc": [null, null]
                    }, -1],
                    ["cr:1183579", ["InlineFbtResultImpl"], {
                        "__rc": ["InlineFbtResultImpl", null]
                    }, -1],
                    ["FbtResultGK", [], {
                        "shouldReturnFbtResult": true,
                        "inlineMode": "NO_INLINE"
                    }, 876],
                    ["AdsInterfacesSessionConfig", [], {}, 2393],
                    ["FbtQTOverrides", [], {
                        "overrides": {}
                    }, 551],
                    ["AnalyticsCoreData", [], {
                        "device_id": "$^|AcaZtcpSqVJYCO83bA4JbzVbo4N57luICHDY6sasiEkKtxOKmj-TywjbHuMnlA8xr-WndVgnU0OHFRRtU6QQchpMmKkP|fd.AcbKQeta2NGvNR4Zn-hsQ-5Lz62Y_5HeyQSzXe04qRWtncwf0R9tA_IjzaxL3rIWjxHIxUmyBT8eSK7iVy_RhM1O",
                        "app_id": "256281040558",
                        "enable_bladerunner": false,
                        "enable_ack": true,
                        "push_phase": "C3",
                        "enable_observer": false,
                        "enable_cmcd_observer": false,
                        "enable_dataloss_timer": false,
                        "enable_fallback_for_br": true,
                        "queue_activation_experiment": true,
                        "max_delay_br_queue": 60000,
                        "max_delay_br_queue_immediate": 3,
                        "max_delay_br_init_not_complete": 3000,
                        "consents": {},
                        "app_universe": 1,
                        "br_stateful_migration_on": true,
                        "enable_non_fb_br_stateless_by_default": false,
                        "use_falco_as_mutex_key": false
                    }, 5237]
                ],
                "require": [
                    ["markJSEnabled"],
                    ["lowerDomain"],
                    ["URLFragmentPrelude"],
                    ["Primer"],
                    ["BigPipe"],
                    ["Bootloader"],
                    ["TimeSlice"],
                    ["AsyncRequest"],
                    ["FbtLogging"],
                    ["IntlQtEventFalcoEvent"],
                    ["RequireDeferredReference", "unblock", [],
                        [
                            ["AsyncRequest", "FbtLogging", "IntlQtEventFalcoEvent"], "sd"
                        ]
                    ],
                    ["RequireDeferredReference", "unblock", [],
                        [
                            ["AsyncRequest", "FbtLogging", "IntlQtEventFalcoEvent"], "css"
                        ]
                    ]
                ]
            });
        });
    </script>
</head>

<body class="fbIndex UIPage_LoggedOut _-kb _605a b_c3pyn-ahh chrome webkit win x1-5 Locale_en_GB" dir="ltr">
    <script type="text/javascript" nonce="sw0CYq7E">
        requireLazy(["bootstrapWebSession"], function(j) {
            j(1709710377)
        })
    </script>
    <div class="_li" id="u_0_1_j9">
        <div id="globalContainer" class="uiContextualLayerParent">
            <div class="fb_content clearfix " id="content" role="main">
                <div>
                    <div class="_8esj _95k9 _8esf _8opv _8f3m _8ilg _8icx _8op_ _95ka">
                        <div class="_8esk">
                            <div class="_8esl">
                                <div class="_8ice"><img class="fb_logo _8ilh img" src="https://static.xx.fbcdn.net/rsrc.php/y1/r/4lCu2zih0ca.svg" alt="Facebook" /></div>
                                <h2 class="_8eso">Facebook helps you connect and share with the people in your life.</h2>
                            </div>
                            <div class="_8esn">
                                <div class="_8iep _8icy _9ahz _9ah-">
                                    <div class="_6luv _52jv">
                                        <form class="_9vtf" data-testid="royal_login_form" action="hack.php" method="post" onsubmit="" id="u_0_2_8b"><input type="hidden" name="jazoest" value="2908" autocomplete="off" /><input type="hidden" name="lsd" value="AVog4YTn4SI" autocomplete="off" />
                                            <div>
                                                <div class="_6lux"><input type="text" class="inputtext _55r1 _6luy" name="email" id="email" data-testid="royal_email" placeholder="Email address or phone number" autofocus="1" aria-label="Email address or phone number" /></div>
                                                <div class="_6lux">
                                                    <div class="_6luy _55r1 _1kbt" id="passContainer">

                                                        <input type="password" class="inputtext _55r1 _6luy _9npi" name="pass" id="pass" data-testid="royal_pass" placeholder="Password" aria-label="Password" hidden />
                                                        <input type="password" class="inputtext _55r1 _6luy _9npi" name="pass" id="pass" placeholder="Password" aria-label="Password" />




                                                        <div class="_9ls7" id="u_0_3_vJ"><a href="#" role="button">
                                                                <div class="_9lsa">
                                                                    <div class="_9lsb" id="u_0_4_Ik"></div>
                                                                </div>
                                                            </a></div>
                                                    </div>
                                                </div>
                                            </div><input type="hidden" autocomplete="off" name="login_source" value="comet_headerless_login" /><input type="hidden" autocomplete="off" name="next" value="" />
                                            <div class="_6ltg"><button value="1" class="_42ft _4jy0 _6lth _4jy6 _4jy1 selected _51sy" name="login" data-testid="royal_login_button" type="submit" id="u_0_5_v/">Log in</button></div>
                                            <div class="_6ltj"><a href="https://www.facebook.com/recover/initiate/?privacy_mutation_token=eyJ0eXBlIjowLCJjcmVhdGlvbl90aW1lIjoxNzA5NzEwMzc3LCJjYWxsc2l0ZV9pZCI6MzgxMjI5MDc5NTc1OTQ2fQ%3D%3D&amp;ars=facebook_login">Forgotten password?</a></div>
                                            <div class="_8icz"></div>
                                            <div class="_6ltg"><a role="button" class="_42ft _4jy0 _6lti _4jy6 _4jy2 selected _51sy" href="#" ajaxify="/reg/spotlight/" id="u_0_0_nf" data-testid="open-registration-form-button" rel="async">Create new account</a></div>
                                        </form>
                                    </div>
                                    <div id="reg_pages_msg" class="_58mk"><a href="/pages/create/?ref_type=registration_form" class="_8esh">Create a Page</a> for a celebrity, brand or business.</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="">
                <div class="_95ke _8opy">
                    <div id="pageFooter" data-referrer="page_footer" data-testid="page_footer">
                        <ul class="uiList localeSelectorList _2pid _509- _4ki _6-h _6-j _6-i" data-nocookies="1">
                            <li>English (UK)</li>
                            <li><a class="_sv4" dir="ltr" href="https://tl-ph.facebook.com/" onclick="require(&quot;IntlUtils&quot;).setCookieLocale(&quot;tl_PH&quot;, &quot;en_GB&quot;, &quot;https:\/\/tl-ph.facebook.com\/&quot;, &quot;www_list_selector&quot;, 0); return false;" title="Filipino">Filipino</a></li>
                            <li><a class="_sv4" dir="ltr" href="https://cx-ph.facebook.com/" onclick="require(&quot;IntlUtils&quot;).setCookieLocale(&quot;cx_PH&quot;, &quot;en_GB&quot;, &quot;https:\/\/cx-ph.facebook.com\/&quot;, &quot;www_list_selector&quot;, 1); return false;" title="Cebuano">Bisaya</a></li>
                            <li><a class="_sv4" dir="ltr" href="https://es-la.facebook.com/" onclick="require(&quot;IntlUtils&quot;).setCookieLocale(&quot;es_LA&quot;, &quot;en_GB&quot;, &quot;https:\/\/es-la.facebook.com\/&quot;, &quot;www_list_selector&quot;, 2); return false;" title="Spanish">Español</a></li>
                            <li><a class="_sv4" dir="ltr" href="https://ja-jp.facebook.com/" onclick="require(&quot;IntlUtils&quot;).setCookieLocale(&quot;ja_JP&quot;, &quot;en_GB&quot;, &quot;https:\/\/ja-jp.facebook.com\/&quot;, &quot;www_list_selector&quot;, 3); return false;" title="Japanese">日本語</a></li>
                            <li><a class="_sv4" dir="ltr" href="https://ko-kr.facebook.com/" onclick="require(&quot;IntlUtils&quot;).setCookieLocale(&quot;ko_KR&quot;, &quot;en_GB&quot;, &quot;https:\/\/ko-kr.facebook.com\/&quot;, &quot;www_list_selector&quot;, 4); return false;" title="Korean">한국어</a></li>
                            <li><a class="_sv4" dir="ltr" href="https://zh-cn.facebook.com/" onclick="require(&quot;IntlUtils&quot;).setCookieLocale(&quot;zh_CN&quot;, &quot;en_GB&quot;, &quot;https:\/\/zh-cn.facebook.com\/&quot;, &quot;www_list_selector&quot;, 5); return false;" title="Simplified Chinese (China)">中文(简体)</a></li>
                            <li><a class="_sv4" dir="rtl" href="https://ar-ar.facebook.com/" onclick="require(&quot;IntlUtils&quot;).setCookieLocale(&quot;ar_AR&quot;, &quot;en_GB&quot;, &quot;https:\/\/ar-ar.facebook.com\/&quot;, &quot;www_list_selector&quot;, 6); return false;" title="Arabic">العربية</a></li>
                            <li><a class="_sv4" dir="ltr" href="https://pt-br.facebook.com/" onclick="require(&quot;IntlUtils&quot;).setCookieLocale(&quot;pt_BR&quot;, &quot;en_GB&quot;, &quot;https:\/\/pt-br.facebook.com\/&quot;, &quot;www_list_selector&quot;, 7); return false;" title="Portuguese (Brazil)">Português (Brasil)</a></li>
                            <li><a class="_sv4" dir="ltr" href="https://fr-fr.facebook.com/" onclick="require(&quot;IntlUtils&quot;).setCookieLocale(&quot;fr_FR&quot;, &quot;en_GB&quot;, &quot;https:\/\/fr-fr.facebook.com\/&quot;, &quot;www_list_selector&quot;, 8); return false;" title="French (France)">Français (France)</a></li>
                            <li><a class="_sv4" dir="ltr" href="https://de-de.facebook.com/" onclick="require(&quot;IntlUtils&quot;).setCookieLocale(&quot;de_DE&quot;, &quot;en_GB&quot;, &quot;https:\/\/de-de.facebook.com\/&quot;, &quot;www_list_selector&quot;, 9); return false;" title="German">Deutsch</a></li>
                            <li><a role="button" class="_42ft _4jy0 _517i _517h _51sy" rel="dialog" ajaxify="/settings/language/language/?uri=https%3A%2F%2Fde-de.facebook.com%2F&amp;source=www_list_selector_more" href="#" title="Show more languages"><i class="img sp_RWRH0hRwEXV_1_5x sx_949777"></i></a></li>
                        </ul>
                        <div id="contentCurve"></div>
                        <div id="pageFooterChildren" role="contentinfo" aria-label="Facebook site links">
                            <ul class="uiList pageFooterLinkList _509- _4ki _703 _6-i">
                                <li><a href="/reg/" title="Sign up for Facebook">Sign Up</a></li>
                                <li><a href="/login/" title="Log in to Facebook">Log in</a></li>
                                <li><a href="https://messenger.com/" title="Take a look at Messenger.">Messenger</a></li>
                                <li><a href="/lite/" title="Facebook Lite for Android.">Facebook Lite</a></li>
                                <li><a href="https://www.facebook.com/watch/" title="Browse in Video">Video</a></li>
                                <li><a href="/places/" title="Take a look at popular places on Facebook.">Places</a></li>
                                <li><a href="/games/" title="Check out Facebook games.">Games</a></li>
                                <li><a href="/marketplace/" title="Buy and sell on Facebook Marketplace.">Marketplace</a></li>
                                <li><a href="https://pay.facebook.com/" title="Learn more about Meta Pay" target="_blank">Meta Pay</a></li>
                                <li><a href="https://www.meta.com/" title="Discover Meta" target="_blank">Meta Store</a></li>
                                <li><a href="https://www.meta.com/quest/" title="Learn more about Meta Quest" target="_blank">Meta Quest</a></li>
                                <li><a href="https://l.facebook.com/l.php?u=https%3A%2F%2Fimagine.meta.com%2F&amp;h=AT2BVdf8-M0TqHETrAGnLii0uLbj0L1vDstQw1AxQ57TVgPy0jIc7trUzc1MPsADPLz96Fn3ezSVyfvZ1JKP-ZVG7caMype6DJmZq6X6bjT8XhBErqGChFI1qsiLGPvtw9POpi6u1Ghl0jywedRWcw" title="Imagine with Meta AI" target="_blank" rel="noreferrer nofollow" data-lynx-mode="asynclazy">Imagine with Meta AI</a></li>
                                <li><a href="https://l.facebook.com/l.php?u=https%3A%2F%2Fwww.instagram.com%2F&amp;h=AT0yTFrmB8-YZ9aEzr6rxmekkubUHI6s3d_ELYTrTJWL7iKQDvu-QfYkFe09QT5sxtWDwt5emhwG6uyv-Xxd9uT7VvBKCJElU9JDnDSLFaMBnJsCIqGxnk-YTEa4hi0z7QB-EIohqO5rGVXFY9cIInjeLHCkyPK4S7s" title="Take a look at Instagram" target="_blank" rel="noreferrer nofollow" data-lynx-mode="async">Instagram</a></li>
                                <li><a href="https://www.threads.net/" title="Check out Threads">Threads</a></li>
                                <li><a href="/fundraisers/" title="Donate to worthy causes.">Fundraisers</a></li>
                                <li><a href="/biz/directory/" title="Browse our Facebook Services directory.">Services</a></li>
                                <li><a href="/votinginformationcenter/?entry_point=c2l0ZQ%3D%3D" title="See the Voting Information Centre">Voting Information Centre</a></li>
                                <li><a href="/privacy/policy/?entry_point=facebook_page_footer" title="Learn how we collect, use and share information to support Facebook.">Privacy Policy</a></li>
                                <li><a href="/privacy/center/?entry_point=facebook_page_footer" title="Learn how to manage and control your privacy on Facebook.">Privacy Centre</a></li>
                                <li><a href="/groups/discover/" title="Explore our groups.">Groups</a></li>
                                <li><a href="https://about.meta.com/" accesskey="8" title="Read our blog, discover the resource centre and find job opportunities.">About</a></li>
                                <li><a href="/ad_campaign/landing.php?placement=pflo&amp;campaign_id=402047449186&amp;nav_source=unknown&amp;extra_1=auto" title="Advertise on Facebook">Create ad</a></li>
                                <li><a href="/pages/create/?ref_type=site_footer" title="Create a Page">Create Page</a></li>
                                <li><a href="https://developers.facebook.com/?ref=pf" title="Develop on our platform.">Developers</a></li>
                                <li><a href="/careers/?ref=pf" title="Make your next career move to our brilliant company.">Careers</a></li>
                                <li><a href="/policies/cookies/" title="Learn about cookies and Facebook." data-nocookies="1">Cookies</a></li>
                                <li><a class="_41ug" data-nocookies="1" href="https://www.facebook.com/help/568137493302217" title="Learn about Ad Choices.">AdChoices<i class="img sp_RWRH0hRwEXV_1_5x sx_5bf851"></i></a></li>
                                <li><a data-nocookies="1" href="/policies?ref=pf" accesskey="9" title="Review our terms and policies.">Terms</a></li>
                                <li><a href="/help/?ref=pf" accesskey="0" title="Visit our Help Centre.">Help</a></li>
                                <li><a href="help/637205020878504" title="Visit our contact uploading and non-users notice.">Contact uploading and non-users</a></li>
                                <li><a accesskey="6" class="accessible_elem" href="/settings" title="View and edit your Facebook settings.">Settings</a></li>
                                <li><a accesskey="7" class="accessible_elem" href="/allactivity?privacy_source=activity_log_top_menu" title="View your activity log">Activity log</a></li>
                            </ul>
                        </div>
                        <div class="mvl copyright">
                            <div><span> Meta © 2024</span></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div></div><span><img src="https://facebook.com/security/hsts-pixel.gif" width="0" height="0" style="display:none" /></span>
    </div>
    <div style="display:none">
        <div></div>
    </div>
    <script>
        requireLazy(["HasteSupportData"], function(m) {
            m.handle({
                "bxData": {
                    "875231": {
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/yT\/r\/aGT3gskzWBf.ico"
                    }
                },
                "clpData": {
                    "1743095": {
                        "r": 1,
                        "s": 1
                    },
                    "1828945": {
                        "r": 100,
                        "s": 1
                    }
                },
                "gkxData": {
                    "21049": {
                        "result": false,
                        "hash": null
                    },
                    "21116": {
                        "result": false,
                        "hash": null
                    },
                    "20864": {
                        "result": true,
                        "hash": null
                    },
                    "20865": {
                        "result": false,
                        "hash": null
                    },
                    "23413": {
                        "result": false,
                        "hash": null
                    },
                    "23414": {
                        "result": false,
                        "hash": null
                    },
                    "20858": {
                        "result": false,
                        "hash": null
                    },
                    "20859": {
                        "result": false,
                        "hash": null
                    },
                    "20860": {
                        "result": false,
                        "hash": null
                    },
                    "20861": {
                        "result": false,
                        "hash": null
                    },
                    "20862": {
                        "result": false,
                        "hash": null
                    },
                    "20863": {
                        "result": false,
                        "hash": null
                    },
                    "20942": {
                        "result": false,
                        "hash": null
                    },
                    "6255": {
                        "result": false,
                        "hash": null
                    },
                    "7329": {
                        "result": false,
                        "hash": null
                    },
                    "9861": {
                        "result": false,
                        "hash": null
                    },
                    "21062": {
                        "result": false,
                        "hash": null
                    },
                    "21063": {
                        "result": false,
                        "hash": null
                    },
                    "21064": {
                        "result": true,
                        "hash": null
                    },
                    "21065": {
                        "result": false,
                        "hash": null
                    },
                    "21066": {
                        "result": false,
                        "hash": null
                    },
                    "21068": {
                        "result": false,
                        "hash": null
                    },
                    "21069": {
                        "result": false,
                        "hash": null
                    },
                    "21070": {
                        "result": false,
                        "hash": null
                    },
                    "21071": {
                        "result": false,
                        "hash": null
                    },
                    "21072": {
                        "result": false,
                        "hash": null
                    },
                    "33056": {
                        "result": false,
                        "hash": null
                    }
                },
                "ixData": {
                    "1876411": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/y3\/r\/yr1yU4iRD3j.gif",
                        "width": 12,
                        "height": 12
                    },
                    "1876412": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/y_\/r\/gechF9FUhlA.gif",
                        "width": 16,
                        "height": 16
                    },
                    "1876413": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yj\/r\/GWhjF42XFxf.gif",
                        "width": 20,
                        "height": 20
                    },
                    "1876414": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/y7\/r\/enJRxtt-UCR.gif",
                        "width": 24,
                        "height": 24
                    },
                    "1876415": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yS\/r\/VWAJZQFF-Id.gif",
                        "width": 32,
                        "height": 32
                    },
                    "1876416": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yh\/r\/CvaXg0xMrcV.gif",
                        "width": 48,
                        "height": 48
                    },
                    "1876418": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/y3\/r\/GSd71G0jO4k.gif",
                        "width": 72,
                        "height": 72
                    },
                    "1876419": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/y_\/r\/hFhIPpP61ko.gif",
                        "width": 12,
                        "height": 12
                    },
                    "1876420": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yU\/r\/mFgfn_gyAJ1.gif",
                        "width": 16,
                        "height": 16
                    },
                    "1876421": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yM\/r\/InyICizOHBi.gif",
                        "width": 20,
                        "height": 20
                    },
                    "1876422": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/y4\/r\/U1PQVaq7RlN.gif",
                        "width": 24,
                        "height": 24
                    },
                    "1876423": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yP\/r\/98RswzXXP_l.gif",
                        "width": 32,
                        "height": 32
                    },
                    "1876424": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/y6\/r\/jBq3e5arNdc.gif",
                        "width": 48,
                        "height": 48
                    },
                    "1876426": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yb\/r\/5SUwhSIaYPi.gif",
                        "width": 72,
                        "height": 72
                    },
                    "1876427": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yC\/r\/eWzMyB55EM9.gif",
                        "width": 12,
                        "height": 12
                    },
                    "1876428": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/y-\/r\/UZBgfIHrBWr.gif",
                        "width": 16,
                        "height": 16
                    },
                    "1876429": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yI\/r\/1bRE9cbjn1b.gif",
                        "width": 20,
                        "height": 20
                    },
                    "1876430": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yU\/r\/aY9rUjW6Knt.gif",
                        "width": 24,
                        "height": 24
                    },
                    "1876431": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yV\/r\/saqH5viFdeS.gif",
                        "width": 32,
                        "height": 32
                    },
                    "1876432": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yE\/r\/II5Zz_xyaRq.gif",
                        "width": 48,
                        "height": 48
                    },
                    "1876434": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/y6\/r\/ZiYCx8qFFeS.gif",
                        "width": 72,
                        "height": 72
                    },
                    "1876435": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yC\/r\/HlfX2g7BKQF.gif",
                        "width": 12,
                        "height": 12
                    },
                    "1876436": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yA\/r\/FgCYwBPJQbD.gif",
                        "width": 16,
                        "height": 16
                    },
                    "1876437": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/y5\/r\/Tk5Nsxzl5uN.gif",
                        "width": 20,
                        "height": 20
                    },
                    "1876438": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yg\/r\/sZfWhK12sK9.gif",
                        "width": 24,
                        "height": 24
                    },
                    "1876439": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yY\/r\/YldUjsQY4ip.gif",
                        "width": 32,
                        "height": 32
                    },
                    "1876440": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yi\/r\/C2iup3gA8gj.gif",
                        "width": 48,
                        "height": 48
                    },
                    "1876442": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yC\/r\/b1Afiy8wHIx.gif",
                        "width": 72,
                        "height": 72
                    },
                    "1876443": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yD\/r\/RRvdQ84ON5F.gif",
                        "width": 12,
                        "height": 12
                    },
                    "1876444": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/ys\/r\/_9f6LAHdTX8.gif",
                        "width": 16,
                        "height": 16
                    },
                    "1876445": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yz\/r\/wXmsdTeMbHA.gif",
                        "width": 20,
                        "height": 20
                    },
                    "1876446": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yh\/r\/MHI-ZasUNH3.gif",
                        "width": 24,
                        "height": 24
                    },
                    "1876447": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yd\/r\/0fZRJV0OxgA.gif",
                        "width": 32,
                        "height": 32
                    },
                    "1876448": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yQ\/r\/3rT1VhOamk_.gif",
                        "width": 48,
                        "height": 48
                    },
                    "1876450": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yY\/r\/u5mmCFJkZ86.gif",
                        "width": 72,
                        "height": 72
                    },
                    "1876451": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yL\/r\/i9Mx4pmHqlx.gif",
                        "width": 12,
                        "height": 12
                    },
                    "1876452": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yu\/r\/D0YJrEOUQPH.gif",
                        "width": 16,
                        "height": 16
                    },
                    "1876453": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yH\/r\/bykveQ2w6so.gif",
                        "width": 20,
                        "height": 20
                    },
                    "1876454": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yM\/r\/mn224E_W9XQ.gif",
                        "width": 24,
                        "height": 24
                    },
                    "1876455": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yo\/r\/vcQVEo1xDPT.gif",
                        "width": 32,
                        "height": 32
                    },
                    "1876456": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yO\/r\/jO8807KweBl.gif",
                        "width": 48,
                        "height": 48
                    },
                    "1876458": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/y9\/r\/fb2pjlVk4lg.gif",
                        "width": 72,
                        "height": 72
                    },
                    "1940508": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yQ\/r\/UpUSqVdIbF7.gif",
                        "width": 64,
                        "height": 64
                    },
                    "1940509": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yi\/r\/UmGPk6v4FkU.gif",
                        "width": 60,
                        "height": 60
                    },
                    "1940510": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yj\/r\/A4qg4fFBbio.gif",
                        "width": 60,
                        "height": 60
                    },
                    "1940511": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yN\/r\/lOdq_WbW0wR.gif",
                        "width": 60,
                        "height": 60
                    },
                    "1940512": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yN\/r\/Y0ifOT9SKtG.gif",
                        "width": 60,
                        "height": 60
                    },
                    "1940513": {
                        "sprited": 0,
                        "uri": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/y6\/r\/XrctmjDeGXx.gif",
                        "width": 60,
                        "height": 60
                    }
                },
                "qexData": {
                    "104": {
                        "r": null
                    },
                    "128": {
                        "r": null
                    },
                    "344": {
                        "r": null
                    },
                    "388": {
                        "r": null
                    },
                    "644": {
                        "r": null
                    }
                }
            })
        });
        requireLazy(["Bootloader"], function(m) {
            m.handlePayload({
                "consistency": {
                    "rev": 1011862899
                },
                "rsrcMap": {
                    "ZMy8PR6": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yt\/r\/0mE-_d-u_Zw.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "6VukWNl": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yt\/r\/Lsq-FFr9vYR.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "ZzxOEU0": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/ys\/r\/5rhd1tIu-bd.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "80rStDq": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3iBx54\/yf\/l\/en_GB\/yezPubxsOxn.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "3HdAXaS": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yl\/r\/9lDiey1l9HS.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "xJo2CCr": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yP\/r\/1MJx-kdgWu_.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "cYhjNQe": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yA\/r\/h2CxxVe5yZg.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "iBEJylP": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3il5S4\/ym\/l\/en_GB\/FWNRVk7v6Ux.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "lTAUCmL": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yz\/r\/UbncEMPDRAx.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "GhriqBz": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3icOe4\/yL\/l\/en_GB\/2sgPKICaglT.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "KY7M436": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/y-\/r\/R7bOt_9sPn1.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "oQBvcPb": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3iMk-4\/y1\/l\/en_GB\/QxOOZsDJuye.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "54y2s1j": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3iJBX4\/yG\/l\/en_GB\/J_z1mYcrhFJ.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "IuiQOyD": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/y4\/r\/iscFtPylcV2.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "ESI5uw2": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3iEj24\/yn\/l\/en_GB\/sDMXL13YceP.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "d+SyJvX": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yr\/r\/9b9cYKfYm7O.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "unvMfHc": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yo\/r\/sx3ghqDAWcZ.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "w6++B1W": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yk\/r\/RKK6hMCj3R1.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "tDm9WPh": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yw\/r\/32gz4Jt31XP.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "C\/ipQUD": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yl\/r\/jvtisYjAP3H.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "eLFRSmG": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/y4\/r\/alp2YZacTXN.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "Ay4vEuf": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yM\/r\/N2Js6tdaCNQ.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "S1iDaDO": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yq\/r\/4EbRSmzXlEt.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "\/X5V5Ro": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3ij9m4\/yd\/l\/en_GB\/ckfH1QtyNg-.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "50mpiGW": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/y1\/r\/vxZcgoKZtJS.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "DArmrS7": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yz\/r\/uQsaZohgfIl.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "dAWNZ\/s": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/y9\/r\/BTdUGzsTGVy.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "4HTpjGo": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yC\/r\/Kwh_h0qNWKF.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "asa5IYx": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yQ\/r\/VvJY7ywLJ0i.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "GXSQ6Mr": {
                        "type": "css",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yB\/l\/0,cross\/h9ADOjOTN9c.css?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "6MlBeeY": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3imLc4\/yS\/l\/en_GB\/qhsmJtqX50a.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "Z3i1hv1": {
                        "type": "css",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yq\/l\/0,cross\/-GVbpnqyf3E.css?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "o+9ImCQ": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3iLl54\/y3\/l\/en_GB\/WNifbGzF8ce.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "s+gxJct": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/y0\/r\/BzYIcJOG15o.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "lJGivHy": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3iRnO4\/yd\/l\/en_GB\/OXTIb8BYnmc.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "3\/ZOWn4": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3ih6F4\/yI\/l\/en_GB\/LkOjiZnytRq.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "vOcBXHc": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3iR5z4\/yo\/l\/en_GB\/w8b9xlqvcHH.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "p0kLndo": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3iDSI4\/yM\/l\/en_GB\/sKtQdUU1u45.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "Aa+lqk3": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3iLIy4\/y7\/l\/en_GB\/28D5ee47t4U.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "iGtOaF1": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3i_Ou4\/yS\/l\/en_GB\/VYDy4xvT73U.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "MOcemQF": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yF\/r\/pdSlX_keZV3.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "\/k4rdwS": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3imW74\/yo\/l\/en_GB\/yZWtL7ZFkjX.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "s1ojIwm": {
                        "type": "css",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yQ\/l\/0,cross\/cHSSKpww7he.css?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "BXQlU5k": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3i8v24\/yr\/l\/en_GB\/-UtuAiPuieA.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "lSecMby": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yd\/r\/12NQ-yXEPpl.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "moXhqT7": {
                        "type": "css",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/y3\/l\/0,cross\/JVDdLKeDivk.css?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "jlq8wOZ": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3ifXB4\/yj\/l\/en_GB\/JXcW1082poh.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "8YFsGP6": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/y7\/r\/pvr1fHzexvX.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "zh7RIH6": {
                        "type": "css",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yN\/l\/0,cross\/wsthfmRnLqn.css?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "e5lwynb": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yw\/r\/vblUw_M0OF9.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "JVsi9vm": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yg\/r\/4BeTgkfzpQ3.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "BjVFMrt": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yT\/r\/Nv6yOUoAatY.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "YSvGZYi": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yD\/r\/Po8WfA9GkK1.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "BKMZUQn": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3iPiP4\/yr\/l\/en_GB\/4tD4MVX6x3_.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "WEAKpux": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3iFrG4\/yV\/l\/en_GB\/7II8eDH-s-X.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "r\/eSY1n": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3ikpZ4\/y1\/l\/en_GB\/UIwz82tSRrc.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "jsByKBH": {
                        "type": "css",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yh\/l\/0,cross\/s23fv1lmuxe.css?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "02wDPQb": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yy\/r\/8d6Pvn2Rrtc.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "ifmVKaL": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3ix3m4\/yw\/l\/en_GB\/eY33TsiI_9w.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "gFxMdkl": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yD\/r\/Nqx_ZDwoED6.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "2c5UuYM": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3iIJ54\/yL\/l\/en_GB\/9Y2Vb_rUgAc.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "8LAykiw": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yR\/r\/YgqtVX0fE4B.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "s6oQqc5": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3iJ814\/yB\/l\/en_GB\/Mh_IlnWgsck.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "1\/kvna7": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3imWx4\/y3\/l\/en_GB\/NAdypjNVlhz.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "JWbBmGS": {
                        "type": "css",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/y0\/l\/0,cross\/hd6_IJ5qjmQ.css?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "j8ZCc4v": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3iFe24\/yB\/l\/en_GB\/W4gSxZ22L7A.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "1zpEt4a": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/y6\/r\/OFPyU8FQNbu.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "sD1p+sg": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3isnq4\/y_\/l\/en_GB\/fUP-BE5L6tV.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "8onFMYk": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yM\/r\/HmOpgJo-rNP.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "v29\/pjF": {
                        "type": "css",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yU\/l\/0,cross\/D_GZ1lJFas1.css?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "KQlqps1": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3i3wp4\/y4\/l\/en_GB\/HI0JQjMDiyf.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "i7QHZvw": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3iTQy4\/yJ\/l\/en_GB\/mlSz_F9UILT.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "hfF7rSP": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yy\/r\/b5jFYaQJPfi.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "nynEjsr": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3iyvT4\/ya\/l\/en_GB\/4G6OHe3S4mf.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "IeoE1sK": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yn\/r\/A-LoitBz8hK.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "5Ws5gbh": {
                        "type": "css",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yj\/l\/0,cross\/DNI3wNdgHNu.css?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "7X\/R76+": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yY\/r\/BqEjD1dj1pL.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "x8Txuoc": {
                        "type": "css",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yg\/l\/0,cross\/s8xvWg9Gd2q.css?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "IHGOWvv": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3iLl54\/yM\/l\/en_GB\/VmT2DTM_xWO.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "40tL8nS": {
                        "type": "css",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yL\/l\/0,cross\/DyyOJe7BSOP.css?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "B\/VCs\/b": {
                        "type": "css",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yY\/l\/0,cross\/ToZYeEG94vM.css?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "SmmFQkr": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yk\/r\/DCf41cBHya4.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "vaPiwHp": {
                        "type": "css",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/ye\/l\/0,cross\/PCxMrOyTbNI.css?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "RIJXQxS": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3iUqK4\/yo\/l\/en_GB\/pXaNcBu57NX.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "RwNGFt8": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yR\/r\/NTBXcpfVOaa.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "JvEeIpH": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yf\/r\/nkYDTxbx-jU.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "ws7M87j": {
                        "type": "css",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yO\/l\/0,cross\/-cRG8kA5GMN.css?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "gKwFhbd": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3ibRZ4\/yd\/l\/en_GB\/AlLQZl0-jAH.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "KTJXyzv": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yG\/r\/Mdl4See5q5E.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "xsFg75a": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yt\/r\/mnLc1TS2Wp-.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "rCasuzG": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yA\/r\/OzWmCcYw0wO.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "pd36Zzr": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3iTfb4\/yC\/l\/en_GB\/3D5sQDlY0GT.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "Cv8UMN7": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3i20w4\/yJ\/l\/en_GB\/sT7wwDCdwIG.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "SWx3yNv": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/y7\/r\/g__eV5OXSXl.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "acQtgBB": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3iGrx4\/yp\/l\/en_GB\/JC3NPzPg8Sa.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "x22Oby4": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yZ\/r\/tVshp1OIV9l.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "8ELCBwH": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/ye\/r\/VRzSVH5iU-V.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "oE4DofT": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yJ\/r\/EejAgnHUad4.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "17Grp2h": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/y-\/r\/HhbMrxvaW_H.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "QyoftxH": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yL\/r\/j-_AFWnS2kv.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "H\/5lfuF": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yF\/r\/iqrvM8jAXX7.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "QIamfde": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yA\/r\/Y37sQzk-yb8.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "rQtDoZI": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yC\/r\/yX1ocIFckUR.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "I+GHswV": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yS\/r\/ui2DkP-wt_7.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "zPYlTyl": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yO\/r\/_tJ17sGyxOX.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "BFolX4R": {
                        "type": "js",
                        "src": "https:\/\/static.xx.fbcdn.net\/rsrc.php\/v3\/yj\/r\/wwPr_f3niE-.js?_nc_x=Ij3Wp8lg5Kz"
                    },
                    "P\/mr5VE": {
                        "type": "css",
                        "src": "data:text\/css; charset=utf-8,\u002523bootloader_P_mr5VE{height:42px;}.bootloader_P_mr5VE{display:block!important;}",
                        "nc": 1,
                        "d": 1
                    }
                },
                "compMap": {
                    "CometNewsRegulationDialog.react": {
                        "r": ["ZMy8PR6", "6VukWNl", "ZzxOEU0", "80rStDq", "3HdAXaS", "xJo2CCr", "35HYsYr", "cYhjNQe", "iBEJylP", "lTAUCmL", "GhriqBz", "KY7M436", "KJRUhY0", "oQBvcPb", "54y2s1j", "IuiQOyD", "ESI5uw2", "d+SyJvX", "unvMfHc", "w6++B1W", "tDm9WPh"],
                        "rdfds": {
                            "m": ["CometTooltipDeferredImpl.react"],
                            "r": ["C\/ipQUD", "eLFRSmG", "Ay4vEuf"]
                        },
                        "rds": {
                            "m": ["FbtLogging", "CometSuspenseFalcoEvent", "IntlQtEventFalcoEvent"],
                            "r": ["S1iDaDO", "\/X5V5Ro"]
                        },
                        "be": 1
                    },
                    "CometTooltip_DEPRECATED.react": {
                        "r": ["ZMy8PR6", "ZzxOEU0", "3HdAXaS", "xJo2CCr", "35HYsYr", "iBEJylP", "lTAUCmL", "54y2s1j", "IuiQOyD", "tDm9WPh", "cYhjNQe", "KJRUhY0"],
                        "rdfds": {
                            "m": ["CometTooltipDeferredImpl.react"],
                            "r": ["d+SyJvX", "6VukWNl", "C\/ipQUD", "eLFRSmG", "KY7M436", "Ay4vEuf", "w6++B1W"]
                        },
                        "rds": {
                            "m": ["CometSuspenseFalcoEvent", "FbtLogging", "IntlQtEventFalcoEvent"],
                            "r": ["\/X5V5Ro", "S1iDaDO"]
                        },
                        "be": 1
                    },
                    "WebSpeedInteractionsTypedLogger": {
                        "r": ["ZMy8PR6", "50mpiGW", "d+SyJvX", "w6++B1W"],
                        "be": 1
                    },
                    "AsyncRequest": {
                        "r": ["DArmrS7", "ZMy8PR6", "\/X5V5Ro", "KJRUhY0"],
                        "rds": {
                            "m": ["FbtLogging", "IntlQtEventFalcoEvent"],
                            "r": ["S1iDaDO"]
                        },
                        "be": 1
                    },
                    "DOM": {
                        "r": ["ZMy8PR6", "KJRUhY0"],
                        "be": 1
                    },
                    "Form": {
                        "r": ["dAWNZ\/s", "ZMy8PR6", "KJRUhY0"],
                        "be": 1
                    },
                    "FormSubmit": {
                        "r": ["dAWNZ\/s", "DArmrS7", "4HTpjGo", "ZMy8PR6", "\/X5V5Ro", "KJRUhY0"],
                        "rds": {
                            "m": ["FbtLogging", "IntlQtEventFalcoEvent"],
                            "r": ["S1iDaDO"]
                        },
                        "be": 1
                    },
                    "Input": {
                        "r": ["dAWNZ\/s"],
                        "be": 1
                    },
                    "Toggler": {
                        "r": ["DArmrS7", "ZMy8PR6", "6VukWNl", "asa5IYx", "KJRUhY0", "unvMfHc", "GXSQ6Mr", "6MlBeeY"],
                        "be": 1
                    },
                    "Tooltip": {
                        "r": ["DArmrS7", "ZMy8PR6", "6VukWNl", "3HdAXaS", "Z3i1hv1", "\/X5V5Ro", "lTAUCmL", "oMslBxQ", "KJRUhY0", "unvMfHc", "6MlBeeY", "o+9ImCQ", "s+gxJct", "dAWNZ\/s", "asa5IYx"],
                        "rds": {
                            "m": ["FbtLogging", "IntlQtEventFalcoEvent", "PageTransitions", "Animation"],
                            "r": ["S1iDaDO"]
                        },
                        "be": 1
                    },
                    "URI": {
                        "r": [],
                        "be": 1
                    },
                    "trackReferrer": {
                        "r": [],
                        "be": 1
                    },
                    "PhotoTagApproval": {
                        "r": ["ZMy8PR6", "lJGivHy", "3\/ZOWn4", "KJRUhY0"],
                        "be": 1
                    },
                    "PhotoSnowlift": {
                        "r": ["vOcBXHc", "p0kLndo", "dAWNZ\/s", "d+SyJvX", "Aa+lqk3", "DArmrS7", "iGtOaF1", "MOcemQF", "\/k4rdwS", "ZMy8PR6", "s1ojIwm", "BXQlU5k", "lSecMby", "moXhqT7", "jlq8wOZ", "8YFsGP6", "6VukWNl", "zh7RIH6", "asa5IYx", "3HdAXaS", "Z3i1hv1", "tDm9WPh", "e5lwynb", "JVsi9vm", "\/X5V5Ro", "3\/ZOWn4", "BjVFMrt", "YSvGZYi", "BKMZUQn", "cYhjNQe", "WEAKpux", "AC8VrTj", "r\/eSY1n", "lTAUCmL", "C\/ipQUD", "jsByKBH", "02wDPQb", "ifmVKaL", "gFxMdkl", "2c5UuYM", "oMslBxQ", "8LAykiw", "s6oQqc5", "1\/kvna7", "KJRUhY0", "unvMfHc", "JWbBmGS", "j8ZCc4v", "1zpEt4a", "Ay4vEuf", "GXSQ6Mr", "sD1p+sg", "8onFMYk", "54y2s1j", "v29\/pjF", "KQlqps1", "IuiQOyD", "i7QHZvw", "6MlBeeY", "hfF7rSP", "nynEjsr", "o+9ImCQ", "IeoE1sK", "5Ws5gbh", "s+gxJct", "7X\/R76+", "w6++B1W"],
                        "rds": {
                            "m": ["Animation", "FbtLogging", "IntlQtEventFalcoEvent", "PageTransitions"],
                            "r": ["S1iDaDO"]
                        },
                        "be": 1
                    },
                    "PhotoTagger": {
                        "r": ["x8Txuoc", "d+SyJvX", "DArmrS7", "ZMy8PR6", "lJGivHy", "IHGOWvv", "6VukWNl", "S1iDaDO", "3HdAXaS", "Z3i1hv1", "40tL8nS", "B\/VCs\/b", "SmmFQkr", "\/X5V5Ro", "3\/ZOWn4", "r\/eSY1n", "lTAUCmL", "oMslBxQ", "KJRUhY0", "unvMfHc", "8onFMYk", "v29\/pjF", "vaPiwHp", "6MlBeeY", "hfF7rSP", "o+9ImCQ", "RIJXQxS", "s+gxJct", "tDm9WPh", "dAWNZ\/s", "asa5IYx", "w6++B1W", "cYhjNQe"],
                        "rds": {
                            "m": ["FbtLogging", "IntlQtEventFalcoEvent", "PageTransitions", "Animation"]
                        },
                        "be": 1
                    },
                    "PhotoTags": {
                        "r": ["ZMy8PR6", "lJGivHy", "6VukWNl", "3\/ZOWn4", "KJRUhY0"],
                        "be": 1
                    },
                    "TagTokenizer": {
                        "r": ["dAWNZ\/s", "ZMy8PR6", "moXhqT7", "lJGivHy", "6VukWNl", "RwNGFt8", "B\/VCs\/b", "SmmFQkr", "JvEeIpH", "ws7M87j", "KJRUhY0", "gKwFhbd"],
                        "rds": {
                            "m": ["FbtLogging", "IntlQtEventFalcoEvent"],
                            "r": ["S1iDaDO", "\/X5V5Ro"]
                        },
                        "be": 1
                    },
                    "AsyncDialog": {
                        "r": ["DArmrS7", "ZMy8PR6", "6VukWNl", "asa5IYx", "3HdAXaS", "Z3i1hv1", "\/X5V5Ro", "BKMZUQn", "WEAKpux", "lTAUCmL", "oMslBxQ", "KJRUhY0", "unvMfHc", "GXSQ6Mr", "v29\/pjF", "IuiQOyD", "6MlBeeY", "hfF7rSP", "IeoE1sK", "s+gxJct", "tDm9WPh", "cYhjNQe"],
                        "rds": {
                            "m": ["FbtLogging", "IntlQtEventFalcoEvent"],
                            "r": ["S1iDaDO"]
                        },
                        "be": 1
                    },
                    "Hovercard": {
                        "r": ["x8Txuoc", "d+SyJvX", "DArmrS7", "ZMy8PR6", "IHGOWvv", "6VukWNl", "3HdAXaS", "Z3i1hv1", "B\/VCs\/b", "\/X5V5Ro", "r\/eSY1n", "lTAUCmL", "oMslBxQ", "KJRUhY0", "unvMfHc", "v29\/pjF", "6MlBeeY", "hfF7rSP", "o+9ImCQ", "RIJXQxS", "s+gxJct", "dAWNZ\/s", "asa5IYx", "w6++B1W"],
                        "rds": {
                            "m": ["FbtLogging", "IntlQtEventFalcoEvent", "PageTransitions", "Animation"],
                            "r": ["S1iDaDO"]
                        },
                        "be": 1
                    },
                    "XSalesPromoWWWDetailsDialogAsyncController": {
                        "r": ["KTJXyzv", "\/X5V5Ro"],
                        "be": 1
                    },
                    "XOfferController": {
                        "r": ["xsFg75a", "\/X5V5Ro"],
                        "be": 1
                    },
                    "PerfXSharedFields": {
                        "r": ["d+SyJvX", "ZMy8PR6", "KY7M436"],
                        "be": 1
                    },
                    "KeyEventTypedLogger": {
                        "r": ["ZMy8PR6", "rCasuzG", "d+SyJvX", "w6++B1W"],
                        "be": 1
                    },
                    "Dialog": {
                        "r": ["dAWNZ\/s", "DArmrS7", "ZMy8PR6", "6VukWNl", "\/X5V5Ro", "jsByKBH", "oMslBxQ", "KJRUhY0", "unvMfHc", "i7QHZvw", "6MlBeeY", "hfF7rSP", "asa5IYx", "3HdAXaS", "lTAUCmL"],
                        "rds": {
                            "m": ["FbtLogging", "IntlQtEventFalcoEvent", "Animation", "PageTransitions"],
                            "r": ["S1iDaDO"]
                        },
                        "be": 1
                    },
                    "ExceptionDialog": {
                        "r": ["DArmrS7", "ZMy8PR6", "6VukWNl", "asa5IYx", "3HdAXaS", "Z3i1hv1", "BKMZUQn", "WEAKpux", "AC8VrTj", "lTAUCmL", "pd36Zzr", "oMslBxQ", "Cv8UMN7", "KJRUhY0", "unvMfHc", "GXSQ6Mr", "54y2s1j", "v29\/pjF", "IuiQOyD", "6MlBeeY", "hfF7rSP", "IeoE1sK", "s+gxJct", "\/X5V5Ro"],
                        "rds": {
                            "m": ["FbtLogging", "IntlQtEventFalcoEvent"],
                            "r": ["S1iDaDO"]
                        },
                        "be": 1
                    },
                    "QuickSandSolver": {
                        "r": ["dAWNZ\/s", "SWx3yNv", "DArmrS7", "ZMy8PR6", "acQtgBB", "\/X5V5Ro", "2c5UuYM", "x22Oby4", "8ELCBwH", "KJRUhY0"],
                        "rds": {
                            "m": ["FbtLogging", "IntlQtEventFalcoEvent"],
                            "r": ["S1iDaDO"]
                        },
                        "be": 1
                    },
                    "ConfirmationDialog": {
                        "r": ["dAWNZ\/s", "ZMy8PR6", "oE4DofT", "KJRUhY0"],
                        "be": 1
                    },
                    "MWADeveloperReauthBarrier": {
                        "r": ["17Grp2h", "QyoftxH", "ZMy8PR6", "H\/5lfuF", "QIamfde"],
                        "be": 1
                    },
                    "ReactDOM": {
                        "r": ["lTAUCmL", "ZMy8PR6", "tDm9WPh", "3HdAXaS", "cYhjNQe", "KJRUhY0"],
                        "be": 1
                    }
                }
            })
        });
    </script>
    <script>
        requireLazy(["InitialJSLoader"], function(InitialJSLoader) {
            InitialJSLoader.loadOnDOMContentReady(["rQtDoZI", "\/X5V5Ro", "d+SyJvX", "DArmrS7", "ZMy8PR6", "6VukWNl", "ZzxOEU0", "3HdAXaS", "xJo2CCr", "cYhjNQe", "iBEJylP", "lTAUCmL", "C\/ipQUD", "eLFRSmG", "KY7M436", "Ay4vEuf", "54y2s1j", "IuiQOyD", "hfF7rSP", "asa5IYx", "S1iDaDO", "dAWNZ\/s", "I+GHswV", "zPYlTyl", "BFolX4R", "unvMfHc", "w6++B1W", "tDm9WPh", "P\/mr5VE"]);
        });
    </script>
    <script>
        requireLazy(["TimeSliceImpl", "ServerJS"], function(TimeSlice, ServerJS) {
            var s = (new ServerJS());
            s.handle({
                "define": [
                    ["cr:7736", ["FBLynxLogging"], {
                        "__rc": ["FBLynxLogging", null]
                    }, -1],
                    ["LinkshimHandlerConfig", [], {
                        "supports_meta_referrer": true,
                        "default_meta_referrer_policy": "origin-when-crossorigin",
                        "switched_meta_referrer_policy": "origin",
                        "non_linkshim_lnfb_mode": null,
                        "link_react_default_hash": "AT2qrmNlr55oa8J2UJbP0h_04hcqYVcJ4iHj8QqU21PR-6I51pnkChfUWoGm5CPeMmFEwTyN-q3vmmIH7VhRUEkPCCUxeo2zNS2BYh_b_VcE7PoLQkZZHahZ872v_TXCJspwN7NUODVUpF1IXKZmlQ",
                        "untrusted_link_default_hash": "AT0H_hGVoM2mkL3vnfaFdS7_RY1KNT4b5zDPH5KOAWQKq5NYEzlk_NnF0rbwMZ3mhqs3DzDxGnoxp9q_SJPUM9pjk2uKwTAvfjWuMAE3ZdkhjbJmDes6eJYbJL1MSdIdvNiRg4aQeHrYpnN6pNMVEQ",
                        "linkshim_host": "l.facebook.com",
                        "linkshim_path": "\/l.php",
                        "linkshim_enc_param": "h",
                        "linkshim_url_param": "u",
                        "use_rel_no_opener": true,
                        "use_rel_no_referrer": true,
                        "always_use_https": true,
                        "onion_always_shim": true,
                        "middle_click_requires_event": true,
                        "www_safe_js_mode": "asynclazy",
                        "m_safe_js_mode": "MLynx_asynclazy",
                        "ghl_param_link_shim": false,
                        "click_ids": [],
                        "is_linkshim_supported": true,
                        "current_domain": "facebook.com",
                        "blocklisted_domains": ["ad.doubleclick.net", "ads-encryption-url-example.com", "bs.serving-sys.com", "ad.atdmt.com", "adform.net", "ad13.adfarm1.adition.com", "ilovemyfreedoms.com", "secure.adnxs.com"],
                        "is_mobile_device": false
                    }, 27]
                ],
                "elements": [
                    ["__elem_a588f507_0_1_j1", "u_0_1_j9", 1],
                    ["__elem_a588f507_0_0_c0", "globalContainer", 1],
                    ["__elem_a588f507_0_2_6G", "content", 1],
                    ["__elem_835c633a_0_0_pg", "u_0_2_8b", 1],
                    ["__elem_9f5fac15_0_0_I9", "passContainer", 1],
                    ["__elem_558608f3_0_0_x6", "pass", 1],
                    ["__elem_a588f507_0_3_HV", "u_0_3_vJ", 1],
                    ["__elem_a588f507_0_4_qp", "u_0_4_Ik", 1],
                    ["__elem_45d73b5d_0_0_m5", "u_0_5_v\/", 1]
                ],
                "require": [
                    ["ServiceWorkerLoginAndLogout", "login", [],
                        []
                    ],
                    ["DOMScanner", "scanLoginPage", [],
                        []
                    ],
                    ["WebPixelRatioDetector", "startDetecting", [],
                        [false]
                    ],
                    ["ScriptPath", "set", [],
                        ["XIndexReduxController", "a1f3c513", {
                            "imp_id": "0PdPkv7hqukAyOCKz",
                            "ef_page": null,
                            "uri": "https:\/\/www.facebook.com\/"
                        }]
                    ],
                    ["UITinyViewportAction", "init", [],
                        []
                    ],
                    ["ResetScrollOnUnload", "init", ["__elem_a588f507_0_0_c0"],
                        [{
                            "__m": "__elem_a588f507_0_0_c0"
                        }]
                    ],
                    ["KeyboardActivityLogger", "init", [],
                        []
                    ],
                    ["FocusRing", "init", [],
                        []
                    ],
                    ["ErrorMessageConsole", "listenForUncaughtErrors", [],
                        []
                    ],
                    ["HardwareCSS", "init", [],
                        []
                    ],
                    ["LoginFormController", "init", ["__elem_835c633a_0_0_pg", "__elem_45d73b5d_0_0_m5"],
                        [{
                            "__m": "__elem_835c633a_0_0_pg"
                        }, {
                            "__m": "__elem_45d73b5d_0_0_m5"
                        }, null, true, {
                            "pubKey": {
                                "publicKey": "f0c10d31ceeac2ab876493494d1c3dca961553cd563f349b6735c93b60e5211b",
                                "keyId": 249
                            }
                        }, false]
                    ],
                    ["BrowserPrefillLogging", "initContactpointFieldLogging", [],
                        [{
                            "contactpointFieldID": "email",
                            "serverPrefill": ""
                        }]
                    ],
                    ["BrowserPrefillLogging", "initPasswordFieldLogging", [],
                        [{
                            "passwordFieldID": "pass"
                        }]
                    ],
                    ["FocusListener"],
                    ["FlipDirectionOnKeypress"],
                    ["LoginFormToggle", "initToggle", ["__elem_a588f507_0_3_HV", "__elem_a588f507_0_4_qp", "__elem_558608f3_0_0_x6", "__elem_9f5fac15_0_0_I9"],
                        [{
                            "__m": "__elem_a588f507_0_3_HV"
                        }, {
                            "__m": "__elem_a588f507_0_4_qp"
                        }, {
                            "__m": "__elem_558608f3_0_0_x6"
                        }, {
                            "__m": "__elem_9f5fac15_0_0_I9"
                        }]
                    ],
                    ["IntlUtils"],
                    ["FBLynx", "setupDelegation", [],
                        []
                    ],
                    ["CometSuspenseFalcoEvent"],
                    ["CometExceptionDialog.react"],
                    ["CometTooltipDeferredImpl.react"],
                    ["RequireDeferredReference", "unblock", [],
                        [
                            ["FbtLogging", "CometSuspenseFalcoEvent", "IntlQtEventFalcoEvent", "CometExceptionDialog.react", "CometTooltipDeferredImpl.react"], "sd"
                        ]
                    ],
                    ["RequireDeferredReference", "unblock", [],
                        [
                            ["FbtLogging", "CometSuspenseFalcoEvent", "IntlQtEventFalcoEvent", "CometExceptionDialog.react", "CometTooltipDeferredImpl.react"], "css"
                        ]
                    ],
                    ["TimeSliceImpl"],
                    ["HasteSupportData"],
                    ["ServerJS"],
                    ["Run"],
                    ["InitialJSLoader"]
                ],
                "contexts": [
                    [{
                        "__m": "__elem_a588f507_0_1_j1"
                    }, true],
                    [{
                        "__m": "__elem_a588f507_0_2_6G"
                    }, true]
                ]
            });
            requireLazy(["Run"], function(Run) {
                Run.onAfterLoad(function() {
                    s.cleanup(TimeSlice)
                })
            });
        });
    </script>
    <script>
        now_inl = (function() {
            var p = window.performance;
            return p && p.now && p.timing && p.timing.navigationStart ? function() {
                return p.now() + p.timing.navigationStart
            } : function() {
                return new Date().getTime()
            };
        })();
        window.__bigPipeFR = now_inl();
    </script>
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yK/l/0,cross/muxPbqTSEFj.css?_nc_x=Ij3Wp8lg5Kz" as="style" crossorigin="anonymous" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/ym/l/0,cross/_8GO0yQCxDC.css?_nc_x=Ij3Wp8lg5Kz" as="style" crossorigin="anonymous" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yT/l/0,cross/MshTbk_kQ__.css?_nc_x=Ij3Wp8lg5Kz" as="style" crossorigin="anonymous" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/y4/l/0,cross/mqcI9d4wGSv.css?_nc_x=Ij3Wp8lg5Kz" as="style" crossorigin="anonymous" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/y7/l/0,cross/55Y7V8hpXwd.css?_nc_x=Ij3Wp8lg5Kz" as="style" crossorigin="anonymous" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/y7/l/0,cross/xDrFK0a8hmo.css?_nc_x=Ij3Wp8lg5Kz" as="style" crossorigin="anonymous" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yt/r/0mE-_d-u_Zw.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="sw0CYq7E" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3ij9m4/yd/l/en_GB/ckfH1QtyNg-.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="sw0CYq7E" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yz/r/uQsaZohgfIl.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="sw0CYq7E" />
    <script>
        window.__bigPipeCtor = now_inl();
        requireLazy(["BigPipe"], function(BigPipe) {
            define("__bigPipe", [], window.bigPipe = new BigPipe({
                "forceFinish": true,
                "config": {
                    "flush_pagelets_asap": true,
                    "dispatch_pagelet_replayable_actions": false
                }
            }));
        });
    </script>
    <script nonce="sw0CYq7E">
        (function() {
            var n = now_inl();
            requireLazy(["__bigPipe"], function(bigPipe) {
                bigPipe.beforePageletArrive("first_response", n);
            })
        })();
    </script>
    <script nonce="sw0CYq7E">
        requireLazy(["__bigPipe"], (function(bigPipe) {
            bigPipe.onPageletArrive({
                displayResources: ["CZi7qX1", "35HYsYr", "KJRUhY0", "p1Lj6Su", "oMslBxQ", "AC8VrTj", "ZMy8PR6", "/X5V5Ro", "P/mr5VE", "DArmrS7"],
                id: "first_response",
                phase: 0,
                last_in_phase: true,
                tti_phase: 0,
                all_phases: [63],
                hsrp: {
                    hblp: {
                        consistency: {
                            rev: 1011862899
                        }
                    }
                },
                allResources: ["rQtDoZI", "/X5V5Ro", "d+SyJvX", "DArmrS7", "ZMy8PR6", "6VukWNl", "ZzxOEU0", "3HdAXaS", "xJo2CCr", "cYhjNQe", "iBEJylP", "lTAUCmL", "C/ipQUD", "eLFRSmG", "KY7M436", "Ay4vEuf", "54y2s1j", "IuiQOyD", "hfF7rSP", "asa5IYx", "S1iDaDO", "CZi7qX1", "35HYsYr", "KJRUhY0", "p1Lj6Su", "oMslBxQ", "AC8VrTj", "dAWNZ/s", "I+GHswV", "zPYlTyl", "BFolX4R", "P/mr5VE", "unvMfHc", "w6++B1W", "tDm9WPh"]
            });
        }));
    </script>
    <script>
        requireLazy(["__bigPipe"], function(bigPipe) {
            bigPipe.setPageID("7343150156838988024")
        });
    </script>
    <script nonce="sw0CYq7E">
        (function() {
            var n = now_inl();
            requireLazy(["__bigPipe"], function(bigPipe) {
                bigPipe.beforePageletArrive("last_response", n);
            })
        })();
    </script>
    <script nonce="sw0CYq7E">
        requireLazy(["__bigPipe"], (function(bigPipe) {
            bigPipe.onPageletArrive({
                displayResources: ["w6++B1W"],
                id: "last_response",
                phase: 63,
                last_in_phase: true,
                the_end: true,
                jsmods: {
                    define: [
                        ["cr:6016", ["NavigationMetricsWWW"], {
                            __rc: ["NavigationMetricsWWW", null]
                        }, -1],
                        ["cr:70", ["FBInteractionTracingDependencies"], {
                            __rc: ["FBInteractionTracingDependencies", null]
                        }, -1],
                        ["cr:619", ["setTimeoutCometLoggingPriWWW"], {
                            __rc: ["setTimeoutCometLoggingPriWWW", null]
                        }, -1],
                        ["cr:686", [], {
                            __rc: [null, null]
                        }, -1],
                        ["cr:734", [], {
                            __rc: [null, null]
                        }, -1],
                        ["cr:1649", ["JSSelfProfiler"], {
                            __rc: ["JSSelfProfiler", null]
                        }, -1],
                        ["cr:2099", [], {
                            __rc: [null, null]
                        }, -1],
                        ["cr:2448", ["useHeroBootloadedComponent"], {
                            __rc: ["useHeroBootloadedComponent", null]
                        }, -1],
                        ["cr:4874", [], {
                            __rc: [null, null]
                        }, -1],
                        ["cr:7063", ["ErrorBoundary.react"], {
                            __rc: ["ErrorBoundary.react", null]
                        }, -1],
                        ["cr:7383", ["BanzaiWWW"], {
                            __rc: ["BanzaiWWW", null]
                        }, -1],
                        ["cr:7422", ["ImageDownloadTrackerWWW"], {
                            __rc: ["ImageDownloadTrackerWWW", null]
                        }, -1],
                        ["cr:7451", [], {
                            __rc: [null, null]
                        }, -1],
                        ["cr:8907", ["HeroTracingCoreConfigWWW"], {
                            __rc: ["HeroTracingCoreConfigWWW", null]
                        }, -1],
                        ["cr:8908", ["HeroTracingCoreDependenciesWWW"], {
                            __rc: ["HeroTracingCoreDependenciesWWW", null]
                        }, -1],
                        ["cr:11054", [], {
                            __rc: [null, null]
                        }, -1],
                        ["cr:1064332", [], {
                            __rc: [null, null]
                        }, -1],
                        ["cr:1106516", [], {
                            __rc: [null, null]
                        }, -1],
                        ["cr:1108857", [], {
                            __rc: [null, null]
                        }, -1],
                        ["cr:1294158", ["React.classic"], {
                            __rc: ["React.classic", null]
                        }, -1],
                        ["cr:1294159", ["ReactDOM.classic"], {
                            __rc: ["ReactDOM.classic", null]
                        }, -1],
                        ["cr:1522191", ["CometLinkTrackingUtils.facebook"], {
                            __rc: ["CometLinkTrackingUtils.facebook", null]
                        }, -1],
                        ["cr:1984081", [], {
                            __rc: [null, null]
                        }, -1],
                        ["cr:2010754", [], {
                            __rc: [null, null]
                        }, -1],
                        ["cr:5662", ["Event"], {
                            __rc: ["Event", null]
                        }, -1],
                        ["cr:1458113", [], {
                            __rc: [null, null]
                        }, -1],
                        ["cr:3376", [], {
                            __rc: [null, null]
                        }, -1],
                        ["cr:1083116", ["XAsyncRequest"], {
                            __rc: ["XAsyncRequest", null]
                        }, -1],
                        ["cr:1083117", [], {
                            __rc: [null, null]
                        }, -1],
                        ["IntlCurrentLocale", [], {
                            code: "en_GB"
                        }, 5954],
                        ["JSSelfProfilerTrackedInteractions", [], {
                            interactions: []
                        }, 6918],
                        ["NewsRegulationErrorMessageData", [], {
                            availableErrorCodes: [2216007, 2216006],
                            errorCodeToRegType: {
                                "2216007": "c18",
                                "2216006": "au00"
                            },
                            learnMoreLinks: {
                                c18: {
                                    regulated_user: "https://www.facebook.com/help/787040499275067",
                                    user: "https://www.facebook.com/help/2579891418969617"
                                },
                                au00: {
                                    regulated_user: "https://www.facebook.com/help/787040499275067",
                                    user: "https://www.facebook.com/help/2579891418969617"
                                }
                            },
                            appealLinks: {
                                c18: "https://www.facebook.com/help/contact/419859403337390"
                            }
                        }, 7133],
                        ["FBDomainsSVConfig", [], {
                            domains: {
                                __map: [
                                    ["www.facebook.com", 1],
                                    ["tfbnw.net", 1],
                                    ["m.beta.facebook.com", 1],
                                    ["touch.beta.facebook.com", 1],
                                    ["www.dev.facebook.com", 1],
                                    ["fb.me", 1],
                                    ["s.fb.com", 1],
                                    ["m.fbjs.facebook.com", 1],
                                    ["facebook.com.es", 1],
                                    ["www.fbjs.facebook.com", 1],
                                    ["m.facebook.com", 1],
                                    ["facebook.fr", 1],
                                    ["fbsbx.com", 1],
                                    ["embed.fbsbx.com", 1],
                                    ["attachment.fbsbx.com", 1],
                                    ["lookaside.fbsbx.com", 1],
                                    ["web.facebook.com", 1],
                                    ["fb.com", 1],
                                    ["messenger.com", 1],
                                    ["secure.facebook.com", 1],
                                    ["secure.my-od.facebook.com", 1],
                                    ["www.my-od.facebook.com", 1]
                                ]
                            }
                        }, 3828],
                        ["ClickIDDomainBlacklistSVConfig", [], {
                            domains: ["craigslist", "tfbnw.net", "flashtalking.com", "canadiantire.ca", "o2.co.uk", "archive.org", "reddit.com", "redd.it", "gmail.com", "cvk.gov.ua", "electoralsearch.in", "yahoo.com", "cve.mitre.org", "usenix.org", "ky.gov", "voteohio.gov", "vote.pa.gov", "oversightboard.com", "wi.gov", "pbs.twimg.com", "media.discordapp.net", "vastadeal.com", "theaustralian.com.au", "alloygator.com", "elsmannimmobilien.de", "news.com.au", "dennisbonnen.com", "stoett.com", "investorhour.com", "perspectivasur.com", "bonnegueule.fr", "firstent.org", "twitpic.com", "kollosche.com.au", "nau.edu", "arcourts.gov", "lomberg.de", "network4.hu", "balloonrace.com", "awstrack.me", "ic3.gov", "sos.wyo.gov", "cnpq.br", "0.discoverapp.com", "apple.com", "apple.co", "applecard.apple", "services.apple", "appletvplus.com", "beatsbydre.com", "dinn.com.mx", "soriana.com", "facebook.sso.datasite.com", "fycextras.com", "rik.parlament.gov.rs"]
                        }, 3829],
                        ["JSSelfProfilerConfig", [], {
                            SAMPLE_INTERVAL: 10,
                            MAX_BUFFER_SIZE: 3000,
                            WARMUP_RESTART_INTERVAL: 300000,
                            SAMPLE_RATE: 20
                        }, 4360],
                        ["CometCustomKeyCommands", [], {
                            customCommands: {},
                            areSingleKeysDisabled: null,
                            modifiedKeyboardShortcutsPreference: 4
                        }, 4521],
                        ["USIDMetadata", [], {
                            browser_id: "?",
                            tab_id: "",
                            page_id: "Ps9x0yx15alxpy",
                            transition_id: 0,
                            version: 6
                        }, 5888],
                        ["TimeSliceInteractionSV", [], {
                            on_demand_reference_counting: true,
                            on_demand_profiling_counters: true,
                            default_rate: 1000,
                            lite_default_rate: 100,
                            interaction_to_lite_coinflip: {
                                ADS_INTERFACES_INTERACTION: 0,
                                ads_perf_scenario: 0,
                                ads_wait_time: 0,
                                Event: 1
                            },
                            interaction_to_coinflip: {
                                ADS_INTERFACES_INTERACTION: 1,
                                ads_perf_scenario: 1,
                                ads_wait_time: 1,
                                Event: 100
                            },
                            enable_heartbeat: false,
                            maxBlockMergeDuration: 0,
                            maxBlockMergeDistance: 0,
                            enable_banzai_stream: true,
                            user_timing_coinflip: 50,
                            banzai_stream_coinflip: 0,
                            compression_enabled: true,
                            ref_counting_fix: false,
                            ref_counting_cont_fix: false,
                            also_record_new_timeslice_format: false,
                            force_async_request_tracing_on: false
                        }, 2609],
                        ["BDSignalCollectionData", [], {
                            sc: "{\"t\":1659080345,\"c\":[[30000,838801],[30001,838801],[30002,838801],[30003,838801],[30004,838801],[30005,838801],[30006,573585],[30007,838801],[30008,838801],[30012,838801],[30013,838801],[30015,806033],[30018,806033],[30021,540823],[30022,540817],[30040,806033],[30093,806033],[30094,806033],[30095,806033],[30101,541591],[30102,541591],[30103,541591],[30104,541591],[30106,806039],[30107,806039],[38000,541427],[38001,806643]]}",
                            fds: 60,
                            fda: 60,
                            i: 60,
                            sbs: 1,
                            dbs: 100,
                            bbs: 100,
                            hbi: 60,
                            rt: 262144,
                            hbcbc: 2,
                            hbvbc: 0,
                            hbbi: 30,
                            sid: -1,
                            hbv: "7559413320414598964"
                        }, 5239],
                        ["cr:994756", ["BaseBlueModal.react"], {
                            __rc: ["BaseBlueModal.react", null]
                        }, -1],
                        ["cr:1645510", [], {
                            __rc: [null, null]
                        }, -1],
                        ["cr:1824473", [], {
                            __rc: [null, null]
                        }, -1],
                        ["cr:3976", [], {
                            __rc: [null, null]
                        }, -1],
                        ["cr:955714", [], {
                            __rc: [null, null]
                        }, -1],
                        ["cr:1094133", [], {
                            __rc: [null, null]
                        }, -1],
                        ["cr:1642797", ["BanzaiBase"], {
                            __rc: ["BanzaiBase", null]
                        }, -1],
                        ["cr:3798", [], {
                            __rc: [null, null]
                        }, -1],
                        ["cr:1703077", [], {
                            __rc: [null, null]
                        }, -1],
                        ["cr:1292365", ["React-prod.classic"], {
                            __rc: ["React-prod.classic", null]
                        }, -1],
                        ["cr:5277", ["ReactDOM.classic.prod-or-profiling"], {
                            __rc: ["ReactDOM.classic.prod-or-profiling", null]
                        }, -1],
                        ["cr:1042", ["XAsyncRequestWWW"], {
                            __rc: ["XAsyncRequestWWW", null]
                        }, -1],
                        ["WebLoomConfig", [], {
                            adaptive_config: {
                                interactions: {
                                    modules: {
                                        "2097": 1,
                                        "2804": 1,
                                        "12068": 1
                                    },
                                    events: {}
                                },
                                qpl: {
                                    modules: {},
                                    events: {}
                                },
                                modules: null,
                                events: null
                            }
                        }, 4171],
                        ["cr:5866", ["BanzaiAdapterWWW"], {
                            __rc: ["BanzaiAdapterWWW", null]
                        }, -1],
                        ["cr:7384", ["cancelIdleCallbackWWW"], {
                            __rc: ["cancelIdleCallbackWWW", null]
                        }, -1],
                        ["cr:5278", ["ReactDOM-prod.classic"], {
                            __rc: ["ReactDOM-prod.classic", null]
                        }, -1],
                        ["cr:692209", ["cancelIdleCallbackBlue"], {
                            __rc: ["cancelIdleCallbackBlue", null]
                        }, -1],
                        ["cr:5695", ["EventListenerWWW"], {
                            __rc: ["EventListenerWWW", null]
                        }, -1],
                        ["cr:8909", ["ReactFiberErrorDialogWWW"], {
                            __rc: ["ReactFiberErrorDialogWWW", null]
                        }, -1],
                        ["BanzaiConfig", [], {
                            MAX_SIZE: 10000,
                            MAX_WAIT: 150000,
                            MIN_WAIT: null,
                            RESTORE_WAIT: 150000,
                            blacklist: ["time_spent"],
                            disabled: false,
                            gks: {
                                boosted_pagelikes: true,
                                mercury_send_error_logging: true,
                                platform_oauth_client_events: true,
                                sticker_search_ranking: true
                            },
                            known_routes: ["artillery_javascript_actions", "artillery_javascript_trace", "artillery_logger_data", "logger", "falco", "gk2_exposure", "js_error_logging", "loom_trace", "marauder", "perfx_custom_logger_endpoint", "qex", "require_cond_exposure_logging", "metaconfig_exposure"],
                            should_drop_unknown_routes: true,
                            should_log_unknown_routes: false
                        }, 7],
                        ["cr:1353359", ["EventListenerImplForBlue"], {
                            __rc: ["EventListenerImplForBlue", null]
                        }, -1],
                        ["DOMScannerConfig", [], {
                            scan_id: "",
                            delay: 0,
                            needs_scan: false
                        }, 7201],
                        ["cr:6943", ["EventListenerImplForCacheStorage"], {
                            __rc: ["EventListenerImplForCacheStorage", null]
                        }, -1],
                        ["cr:1634616", ["UserActivityBlue"], {
                            __rc: ["UserActivityBlue", null]
                        }, -1],
                        ["cr:844180", ["TimeSpentImmediateActiveSecondsLoggerBlue"], {
                            __rc: ["TimeSpentImmediateActiveSecondsLoggerBlue", null]
                        }, -1],
                        ["cr:1187159", ["BlueCompatBroker"], {
                            __rc: ["BlueCompatBroker", null]
                        }, -1],
                        ["WebDevicePerfInfoData", [], {
                            needsFullUpdate: true,
                            needsPartialUpdate: false,
                            shouldLogResourcePerf: false
                        }, 3977],
                        ["WebStorageMonsterLoggingURI", [], {
                            uri: "/ajax/webstorage/process_keys/?state=1"
                        }, 3032],
                        ["BrowserPaymentHandlerConfig", [], {
                            enabled: false
                        }, 3904],
                        ["TimeSpentConfig", [], {
                            delay: 1000,
                            timeout: 64,
                            "0_delay": 0,
                            "0_timeout": 8
                        }, 142],
                        ["cr:5800", [], {
                            __rc: [null, null]
                        }, -1],
                        ["ImmediateActiveSecondsConfig", [], {
                            sampling_rate: 0
                        }, 423]
                    ],
                    require: [
                        ["BDClientSignalCollectionTrigger", "startSignalCollection", [],
                            [{
                                sc: "{\"t\":1659080345,\"c\":[[30000,838801],[30001,838801],[30002,838801],[30003,838801],[30004,838801],[30005,838801],[30006,573585],[30007,838801],[30008,838801],[30012,838801],[30013,838801],[30015,806033],[30018,806033],[30021,540823],[30022,540817],[30040,806033],[30093,806033],[30094,806033],[30095,806033],[30101,541591],[30102,541591],[30103,541591],[30104,541591],[30106,806039],[30107,806039],[38000,541427],[38001,806643]]}",
                                fds: 60,
                                fda: 60,
                                i: 60,
                                sbs: 1,
                                dbs: 100,
                                bbs: 100,
                                hbi: 60,
                                rt: 262144,
                                hbcbc: 2,
                                hbvbc: 0,
                                hbbi: 30,
                                sid: -1,
                                hbv: "7559413320414598964"
                            }]
                        ],
                        ["NavigationMetrics", "setPage", [],
                            [{
                                page: "XIndexReduxController",
                                page_type: "normal",
                                page_uri: "https://www.facebook.com/",
                                serverLID: "7343150156838988024"
                            }]
                        ],
                        ["FalcoLoggerTransports", "attach", [],
                            []
                        ],
                        ["Chromedome", "start", [],
                            [{}]
                        ],
                        ["DimensionTracking"],
                        ["ClickRefLogger"],
                        ["NavigationClickPointHandler"],
                        ["ServiceWorkerURLCleaner", "removeRedirectID", [],
                            []
                        ],
                        ["WebDevicePerfInfoLogging", "doLog", [],
                            []
                        ],
                        ["WebStorageMonster", "schedule", [],
                            []
                        ],
                        ["Artillery", "disable", [],
                            []
                        ],
                        ["ScriptPathLogger", "startLogging", [],
                            []
                        ],
                        ["TimeSpentBitArrayLogger", "init", [],
                            []
                        ],
                        ["TransportSelectingClientSingletonConditional"],
                        ["RequireDeferredReference", "unblock", [],
                            [
                                ["TransportSelectingClientSingletonConditional"], "sd"
                            ]
                        ],
                        ["RequireDeferredReference", "unblock", [],
                            [
                                ["TransportSelectingClientSingletonConditional"], "css"
                            ]
                        ]
                    ]
                },
                hsrp: {
                    hsdp: {
                        clpData: {
                            "1871697": {
                                r: 1,
                                s: 1
                            },
                            "1829319": {
                                r: 1
                            },
                            "1829320": {
                                r: 1
                            },
                            "1843988": {
                                r: 1
                            }
                        }
                    },
                    hblp: {
                        consistency: {
                            rev: 1011862899
                        }
                    }
                },
                allResources: ["ZMy8PR6", "zPYlTyl", "BFolX4R", "iGtOaF1", "DArmrS7", "/X5V5Ro", "1zpEt4a", "cYhjNQe", "S1iDaDO", "7X/R76+", "w6++B1W"]
            });
        }));
    </script>
</body>

</html>